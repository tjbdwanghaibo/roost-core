#!/usr/bin/env python3
"""Replay offline: python3 -B prior_fanout.py /path/to/tail100 > prior_fanout.json
No service, repository imports, third-party dependencies or extraction. Time: integer ns.
"""
import argparse
import bisect
import collections
import gzip
import hashlib
import json
import pathlib
import zipfile

BINS = ('0', '1', '2-8', '9-64', '65+')
SUMS = ('prepare_visits', 'covered_visits', 'prepare_input_subs', 'covered_input_subs',
        'prepare_object_wall_ns', 'covered_object_wall_ns')
PIN = {'mixed': 'acab9903bcefbcb4b183726323ccea8d98361c8d1f6d25694c0f49852fa76f9d',
       'backlog': '2749caad078e44cfdf92f35771cf16b42b60c0ebd7c58fc0db4c3a2df7cfa8df'}

def require(x, s):
    if not x: raise ValueError(s)

def holds_index(facts):
    # Prefix max is over individual selections, NOT a union of consecutive short holds.
    times = collections.defaultdict(list)
    for f in facts:
        require(f['Exception'] == 0 and 0 <= f['Registered'] <= f['Eligible'] <= f['Selected'] <= f['Released'], 'non-clean fact')
        times[f['Subject']].append((f['Registered'], f['Selected']))
    out = {}
    for s, rows in times.items():
        starts, endmax = [], []; m = -1
        for a,b in sorted(rows):
            starts.append(a); m = max(m,b); endmax.append(m)
        out[s] = (starts,endmax)
    return out

def covered(idx, s, a, b):
    if s not in idx: return False
    starts, endmax = idx[s]; i = bisect.bisect_right(starts, a)-1
    return i >= 0 and endmax[i] >= b

class Union:
    def __init__(self, ranges):
        merged = []
        for a,b in sorted(ranges):
            if a >= b: continue
            if merged and a <= merged[-1][1]: merged[-1][1] = max(b,merged[-1][1])
            else: merged.append([a,b])
        self.spans = merged; self.starts = [a for a,b in merged]; self.ends = [b for a,b in merged]
        self.size = sum(b-a for a,b in merged)
    def overlap(self,a,b):
        i = bisect.bisect_right(self.ends,a); n=0
        while i < len(self.spans) and self.starts[i] < b:
            n += min(self.ends[i],b) - max(self.starts[i],a); i+=1
        return n

def table(): return [[0]*len(SUMS) for name in BINS]

def add(tab,j,k,c,n):
    r = tab[j]; r[0]+=1; r[2]+=k; r[4]+=n
    if c: r[1]+=1; r[3]+=k; r[5]+=n

def summarize(tab):
    return {g:dict(zip(SUMS,r)) for g,r in zip((*BINS,'total'),[*tab,list(map(sum,zip(*tab)))])}

def run(root, label):
    path = root/('sweep' if label=='backlog' else '')/'c4-raw.zip'
    with path.open('rb') as fp: sha=hashlib.file_digest(fp,'sha256').hexdigest()
    require(sha==PIN[label], 'unexpected archive: '+str(path))
    with zipfile.ZipFile(path) as z:
        stock = json.loads(z.read('c4/stock.json')); raw=z.read('c4/trace.json.gz')
        require(hashlib.sha256(raw).hexdigest()==stock['trace'],'trace sha'); t=json.loads(gzip.decompress(raw))
    start,end=t['formal_ns'],t['end_ns']; mid=(start+end)//2
    require(len(t['interests'])==1, 'expected a single stable owner')
    facts=t['interests'][0]['Facts']; idx=holds_index(facts); fk={(f['Subject'],f['Planned'],f['Changed']):f for f in facts}
    require(len(fk)==len(facts)==len({f['ID'] for f in facts}),'ambiguous fact')
    # Identical delivery ordering to stock auditable cohorts: all formal-planned, any endpoint.
    ranked=sorted((r[5]-r[4],c['index'],r[6],r[7],r[0],r[1],r[2],r[3],r[11],r[4],r[5],i)
                  for c in t['client']['clients'] for i,r in enumerate(c['rows'] or ()) if start < r[3] <= end)
    windows={}; meta={}
    for name,rows in [('all',ranked),('first_planned_half',[r for r in ranked if r[7]<=mid]),
                      ('second_planned_half',[r for r in ranked if r[7]>mid])]:
        k=(len(rows)+99)//100; tail=rows[-k:] if k else []
        # key a fact once; even two distinct facts' overlapping time must be counted only once.
        selected={r[4:5]+r[7:9] for r in tail}; u=Union((fk[key]['Eligible'],fk[key]['Selected']) for key in selected)
        windows[name]=u; meta[name]=dict(population=len(rows),tail_deliveries=k,unique_facts=len(selected),
            union_ns=u.size,windows_ns=u.spans,at_or_before_formal_end=sum(r[10]<=end for r in tail))
    visits={s:table() for s in ['complete_ordinary_formal','formal_time_clip_all_rounds']}
    for group in windows:
        for scope in ['all_rounds','complete_ordinary_formal']:
            visits[f'tail_{group}/{scope}']=table()
    rs=t['server']['rounds']; ws=t['server']['round_work']; caps={r:(a,b) for r,k,a,b in t['server']['spans'] if k=='capture_subjects'}
    require(len(rs)==len(ws)==len({r[0] for r in rs}), 'round identity')
    nr=nok=0; prev_end=-1
    for (rid,lo,hi,empty,success,force),w in zip(rs,ws):
        require(rid==w['round'] and prev_end<=lo<=hi, 'round ownership/overlap'); prev_end=hi
        regular=success and not force and start<=lo<=hi<=end; nr+=1; nok+=regular
        active=[(u,visits[f'tail_{g}/all_rounds'],visits[f'tail_{g}/complete_ordinary_formal'])
                for g,u in windows.items() if u.overlap(lo,hi)>0]
        cap=caps.get(rid); prev=cap[0] if cap else lo; ps=-1; counts=[0,0]; inputs=[0,0]
        for sub,a,b,cls,inp in w['objects'] or ():
            require(cap and lo<=cap[0]<=prev<=a<=b<=cap[1]<=hi and ps<sub and cls in (0,1) and inp>=0,'object identity/disjointness'); prev=b; ps=sub
            counts[cls]+=1; inputs[cls]+=inp
            if not cls: continue
            j=bisect.bisect_left((0,1,8,64),inp); c=covered(idx,sub,a,b)
            if regular: add(visits['complete_ordinary_formal'],j,inp,c,b-a)
            n=min(b,end)-max(a,start)
            if n>0: add(visits['formal_time_clip_all_rounds'],j,inp,c,n)
            for u,whole,formal in active:
                n=u.overlap(a,b)
                if n>0:
                    add(whole,j,inp,c,n)
                    if regular: add(formal,j,inp,c,n)
        require(counts==[w['no_prepare'],w['prepare']] and inputs==[w['no_prepare_input'],w['prepare_input']], 'branch/count/input mismatch')
    tables={s:summarize(v) for s,v in visits.items()}
    for name,u in windows.items(): require(tables[f'tail_{name}/all_rounds']['total']['prepare_object_wall_ns']<=u.size,'union overcount')
    if label=='backlog':
        for scope,expected in [('formal_time_clip_all_rounds',(646358,646060,24016293556,24015547260)),
                               ('tail_all/all_rounds',(202321,201793,8087185812,8086861447))]:
            tot=tables[scope]['total']; require(tuple(tot[s] for s in (SUMS[0],SUMS[1],SUMS[4],SUMS[5]))==expected, 'prior independent service_check reconciliation: '+scope)
    return dict(raw_relative=path.relative_to(root).as_posix(),raw_sha256=sha,trace_sha256=stock['trace'],formal_ns=[start,mid,end],
                recorded_rounds=nr,complete_ordinary_formal_rounds=nok,tail_sets=meta,by_input_subs=tables)

def selftest():
    f=lambda s,a,b:dict(Subject=s,Registered=a,Eligible=a,Selected=b,Released=b,Exception=0)
    idx=holds_index([f(10,2,15),f(10,4,6),f(10,15,20),f(11,1,30)])
    require(covered(idx,10,5,15) and not covered(idx,10,9,19) and not covered(idx,12,5,8),'single whole-visit witness including endpoints')
    u=Union([(8,13),(3,10),(3,10),(13,17),(20,21),(50,50)])
    require(u.spans==[[3,17],[20,21]] and u.overlap(10,21)==8 and u.overlap(17,20)==0,'partial overlap deduplication')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('tail100',type=pathlib.Path);args=p.parse_args();selftest()
    out={label:run(args.tail100,label) for label in PIN}
    print(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False))
