"""Strict stage bounds for the original A trace; read only. Usage: python3 -B bounds.py trace.json.gz"""
import gzip
import json
import sys
from bisect import bisect_right
from collections import Counter

with gzip.open(sys.argv[1]) as f:
    t = json.load(f)
start, end = t['formal_ns'], t['end_ns']
mid = (start + end) // 2
rs = {r[0]: r for r in t['server']['rounds']}
facts = {(f['Subject'], f['Planned'], f['Changed']): f for o in t['interests'] for f in o['Facts']}
rank = sorted((r[5]-r[4], c['index'], r[6], r[7], r[0], r[1], r[2], r[3], r[11], r[4], r[5], i) for c in t['client']['clients'] for i, r in enumerate(c['rows'] or []) if start < r[3] <= end)
assert rank
chosen = {facts[r[4],r[7],r[8]]['ID']: facts[r[4],r[7],r[8]] for r in rank[-((len(rank)+99)//100):]}
windows = []
for a,b in sorted((v['Eligible'],v['Selected']) for v in chosen.values()):
    assert b >= a
    if b == a:
        continue
    if windows and a <= windows[-1][1]:
        windows[-1][1] = max(b, windows[-1][1])
    else:
        windows.append([a,b])
begins = [a for a,b in windows]

def overlap(a,b):
    s = 0
    i = max(0,bisect_right(begins,a)-1)
    while i < len(windows) and windows[i][0] < b:
        x,y = windows[i]
        s += max(0, min(y,b)-max(x,a))
        i += 1
    return s

groups = {k:Counter() for k in ('formal','first','second','tail')}
last = {}
for w in t['server']['round_work']:
    rid = w['round']; _,a,b,empty,ok,force = rs[rid]
    scope = [] if force or not ok or not start <= a <= b <= end else ['formal']+(['first'] if b<=mid else ['second'] if a>=mid else [])
    target, tailtarget, totals = Counter(), Counter(), Counter()
    for (sid,x,y,called,subs),v in zip(w['objects'] or [],w.get('meter_codes') or [],strict=True):
        k = v & 15
        totals[k] += y-x
        if not called:
            continue
        if last.get(sid,False):
            for g in scope:
                groups[g]['hint_calls'] += 1
                groups[g]['hint_success'] += k in (7,8)
            if k in (1,2):
                target[k] += y-x
                tailtarget[k] += overlap(x,y)
                for g in scope:
                    groups[g]['repeat'] += 1
                    groups[g]['dense_repeat'] += subs >= 65
        # Same stable subject/state per ID in this fixture; noPrepare & absent visits keep the last actual result.
        last[sid] = (v>>5)&3 == 1
    for row in w.get('meter_costs') or []:
        k, body, copy = row[0], row[5], row[9]
        assert totals[k] == body and 0 <= copy <= body
        for g in scope:
            groups[g]['object_ns'] += body
        if k not in (1,2):
            continue
        for g in scope+['tail']:
            subset = tailtarget[k] if g=='tail' else target[k]
            assert 0 <= subset <= body
            # For a class/round of wall B, stage C and target subset T: max(0,C-(B-T)) <= stage intersect target <= min(C,T).
            groups[g]['copy_lower_ns'] += max(0, copy-(body-subset))
            groups[g]['copy_upper_ns'] += min(copy,subset)
            groups[g]['target_object_ns'] += subset

groups['tail']['eligible_union_ns'] = sum(b-a for a,b in windows)
groups['tail']['facts'] = len(chosen)
print(json.dumps(groups,sort_keys=True,indent=2))
