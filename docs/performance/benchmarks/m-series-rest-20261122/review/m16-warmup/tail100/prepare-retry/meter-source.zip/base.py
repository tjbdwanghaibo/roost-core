from pathlib import Path
import subprocess as sp,sys,json,os,hashlib,gzip,zipfile,difflib,re,fcntl,shutil,time,importlib.util
D=Path(__file__).resolve().parent;W=D.parent;T=W/'m16-tail100';R=Path(os.environ['MESHY_PROJECT']).resolve()/'.claude/worktrees/main-review-fixes';G=W/'m16-warmup-fixed/generated';S=W/'m-series-fixes';E=Path('framework/sync/entitysync');P=Path('codegen/internal/entity/testdata/nestgame');Q=R/'docs/performance/benchmarks/m-series-rest-20261122/review/m16-warmup/tail100';H='24b704bf1627d4db3f64c4f87880bfce808af326';sha=lambda b:hashlib.sha256(b).hexdigest();readj=lambda p:json.loads(Path(p).read_bytes());meta=readj(Q/'build.json');assert sp.check_output(['git','-C',R,'rev-parse','HEAD'],text=True).strip()==H and sp.check_output(['git','-C',R,'branch','--show-current'],text=True).strip()=='fix/main-review-fixes' and not sp.check_output(['git','-C',R,'diff','HEAD','--','framework','codegen']);baseline=readj(T/'build/overlay.json')['Replace'];pathkey=lambda n: str(G/Path(n).relative_to(P) if Path(n).is_relative_to(P) else R/n);assert all(sha(Path(baseline[pathkey(n)]).read_bytes())==h for n,h in meta['sources'].items());assert all(sha((W/'m16-rev-slot/prod-a'/n).read_bytes())==h for n,h in meta['product_A_files'].items());assert all(sha((G/n).read_bytes())==h for n,h in readj(Q.parent/'fixed-capture/provenance.json')['build']['go_fixture_sources'].items());assert sha((S/'run-m16.py').read_bytes())==readj(Q.parent/'fixed-capture/provenance.json')['runner_sha256'];env={k:v for k,v in os.environ.items() if not k.startswith(('M16_','ROOST_'))};env.update(GOWORK='off',GOPROXY='off',GOSUMDB='off',GOFLAGS='-p=2',GOMAXPROCS='2');sys.path.insert(0,str(W/'m16-rev-slot/c4'));from wrapper import isolation,clear,stop_group
sys.path.insert(0,str(Q))
def work_idle():
 clear(isolation('before'))
 with (S/'measure.lock').open('r+b') as f:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
def mod(name,p):
 spc=importlib.util.spec_from_file_location(name,p);o=importlib.util.module_from_spec(spc);sys.modules[name]=o;spc.loader.exec_module(o);return o
def one(s,a,b):assert s.count(a)==1,('missing/ambiguous',a);return s.replace(a,b)
def run(args,cwd=R):print('+',' '.join(map(str,args)),flush=True);sp.run(args,cwd=cwd,env=env,check=True)
def patch(n,a,b):return ''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),'a/'+n if a else '/dev/null','b/'+n))
def inputs():
 ns={str(f.relative_to(R)) for d in (R/'framework/entity',R/E,R/P) for f in d.rglob('*.go')};ns.update(meta['sources']);src={}
 for n in ns:
  k=pathkey(n);effective=Path(baseline[k]) if k in baseline else R/n;src[n]=effective.read_text()
 return src
