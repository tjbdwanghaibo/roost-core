"""Frozen selector and fail-closed serial A1 B1 B2 A2 scorer. No Go or services here."""
from collections import Counter
from pathlib import Path
from statistics import median
import gzip, hashlib, json, math, re, sys

CASES=('sparse_held','dense_held','sparse_success','dense_success')
METRICS=('capture-ns/op','ns/op','internal-flush-ns/op','B/op','allocs/op','heap-allocs/sample')
TAGS=('a1','b1','b2','a2')
def need(x,msg):
    if not x: raise ValueError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def select(path):
    # Call only after parent validated stock output, meter and row alignment for this original A c4.
    with gzip.open(path,'rt') as fh:t=json.load(fh)
    s=t['server']; start=t['formal_ns'];end=t['end_ns']; costs=Counter();n=Counter();repeats=Counter();prev={}
    rounds={row[0]:row for row in s['rounds']};seen=set();need(len(rounds)==len(s['rounds']),'duplicate round')
    for w in s['round_work']:
        rid=w['round'];need(rid not in seen,'duplicate work');seen.add(rid)
        _,a,b,empty,ok,force=rounds[rid];items=w['objects'] or [];codes=w.get('meter_codes') or []
        need(len(items)==len(codes),'meter row alignment');used=set()
        if not (start<=a<=b<=end and ok and not force):continue
        for (sid,x,y,wants,fan),code in zip(items,codes):
            need(sid not in used and a<=x<=y<=b and fan>=0,'invalid object intervals');used.add(sid)
            if code&15!=1 or (code>>5)&3!=1 or (code>>7)&3 not in (1,2):continue
            need(wants==1,'hold without actual prepare');k='sparse_held' if fan<=8 else 'dense_held' if fan>=65 else 'unrepresented_9_to_64'
            costs[k]+=y-x;n[k]+=1
            if prev.get(sid)==(rid-1,k):repeats[k]+=1
            prev[sid]=(rid,k)
    need(seen==set(rounds),'missing round work');primary=next((k for k in CASES[:2] if 2*costs[k]>sum(costs.values()) and repeats[k]>0),None)
    return {'trace_sha256':sha(path),'ordinary_complete_formal_policy_hold_commit_pending_settled':dict(n),'observed_object_ns':dict(costs),'same_bin_adjacent_settled_retries':dict(repeats),'primary':primary,'metric':'ns/op','eligible':primary is not None}

def contract(log,kind,count):
    rows=Counter(l for l in log.splitlines() if l.startswith('M16_RETRY_'))
    need('PASS' in log.splitlines() and rows and set(rows.values())=={count},'incomplete/nonrepeatable contract '+kind)
    if kind=='tiny':
        need(len(rows)==1,'multiple tiny outputs');line=next(iter(rows));m=re.fullmatch(r'M16_RETRY_RAW rounds=7 bytes=(\d+) raw=([a-f0-9]+)',line);need(m and len(bytes.fromhex(m[2]))==int(m[1]),'invalid raw')
    else:
        need(len(rows)==4 and {r.split()[1] for r in rows}==set(CASES) and all(re.fullmatch(r'M16_RETRY_SHAPE \w+ bytes=[1-9]\d* sha256=[0-9a-f]{64}',r) for r in rows),'invalid shape output')
    return sorted(rows)

def score(d,primary):
    d=Path(d);need(primary in CASES[:2],'no evidence-supported primary');rows={};out={};guards={}
    for k in ('tiny','shape'):
        a=contract((d/('a-'+k+'.log')).read_text(),k,3);b=contract((d/('b-'+k+'.log')).read_text(),k,3);need(a==b,'wire mismatch: '+k)
    for tag in TAGS:
        log=(d/(tag+'.log')).read_text();need('PASS' in log.splitlines(),'missing PASS: '+tag);rows[tag]={k:[] for k in CASES}
        for l in log.splitlines():
            if not l.startswith('BenchmarkM16RetryFixed/'):continue
            v=l.split();m=re.fullmatch(r'BenchmarkM16RetryFixed/(\w+)-2',v[0]);need(m and m[1] in CASES and v[1]=='32' and (len(v)-2)%2==0,'unexpected row: '+l);units=v[3::2];need(set(units)==set(METRICS) and len(units)==len(METRICS),'benchmark schema');r=dict(zip(units,map(float,v[2::2])));need(all(math.isfinite(n) and n>0 for n in r.values()),'empty/invalid measurement');rows[tag][m[1]].append(r)
        need(all(len(v)==5 for v in rows[tag].values()),'need exactly 5 samples/case/tag')
    for c in CASES:
        out[c]={}
        for m in METRICS:
            v={tag:[r[m] for r in rows[tag][c]] for tag in TAGS};med={k:median(x) for k,x in v.items()};med.update({k:median(v[k+'1']+v[k+'2']) for k in ('a','b')});out[c][m]=med
            if c==primary and m=='ns/op':guards['primary_both_and_5pct']=med['b1']<med['a1'] and med['b2']<med['a2'] and med['b']<=.95*med['a']
            if m in ('ns/op','capture-ns/op','internal-flush-ns/op'):guards[c+'/'+m+'/pooled_no_5pct_regression']=med['b']<=1.05*med['a']
            if m in ('allocs/op','heap-allocs/sample'):guards[c+'/'+m+'/no_extra']=all(med[b]<=med[a] for b,a in [('b1','a1'),('b2','a2'),('b','a')])
    return {'primary':primary,'primary_metric':'whole Flush ns/op','pass':all(guards.values()),'guards':guards,'medians':out,'samples':rows}

if __name__=='__main__':
    need(len(sys.argv)==3 and sys.argv[1]=='select','usage: gate.py select TRACE.json.gz');print(json.dumps(select(Path(sys.argv[2])),indent=2))
