package entitysync

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"runtime"
	"testing"
	"time"

	"github.com/tjbdwanghaibo/roost-core/framework/entity"
	"github.com/tjbdwanghaibo/roost-core/framework/sync/frame"
)

// Standalone test overlay. No test hooks in production, no Manager.Start,
// no fake pending marks, no scheduler, Trace, network, or package test helpers.
type retryFixedWorld struct {
	m       *Manager
	s       []*entity.SubjectSyncState
	release []func()
	first   []time.Time
	frames  [][]byte // exactly one slot per real session; frame.Encode owns its output
	dec     []*Decoder
	tick    []uint32
}

func retryFixedOK(t testing.TB, err error) {
	t.Helper()
	if err != nil { t.Fatal(err) }
}

func (w *retryFixedWorld) Push(_ context.Context, sid SessionID, p []byte) error {
	if sid < 1 || int(sid) >= len(w.frames) || w.frames[sid] != nil || len(p) == 0 {
		return fmt.Errorf("unexpected fixed input push: sid=%d bytes=%d", sid, len(p))
	}
	w.frames[sid] = p
	return nil
}

func retryFixedNew(t testing.TB, n, sessions int, subscribed func(int,int) bool, firstDelta func()) *retryFixedWorld {
	t.Helper()
	w := &retryFixedWorld{s: make([]*entity.SubjectSyncState,n), release:make([]func(),n),first:make([]time.Time,n),frames:make([][]byte,sessions+1),dec:make([]*Decoder,sessions+1),tick:make([]uint32,sessions+1)}
	lim := frame.DefaultLimits()
	lim.MaxObjects = n
	var err error
	w.m,err = NewManager(ManagerConfig{Mode:ModeOnChange,Interval:time.Hour,Transport:w, Limits:lim})
	retryFixedOK(t,err)
	t.Cleanup(func(){ for _,f:=range w.release {if f!=nil {f()}}; retryFixedOK(t,w.m.Close(context.Background())) })
	for sid:=1;sid<=sessions;sid++ {retryFixedOK(t,w.m.OpenSession(SessionID(sid))); w.dec[sid]=NewDecoder(lim)}
	for i:=0;i<n;i++ {
		id:=int64(i+1)
		// The packer supplies immutable subject-specific bytes of fixed size; no instrumentation.
		snap:=entity.TakeFrozenSyncPayload(1,[]byte{'S',byte(id)})
		delta:=entity.TakeFrozenSyncPayload(1,[]byte{'D',byte(id)})
		packDelta:=func(entity.SyncProfile,uint64)(entity.FrozenSyncPayload,error){return delta,nil}
		// Select the tiny contract's callback only at construction. Measured packers
		// have no hook branch, counter or allocation (payloads are immutable).
		if firstDelta!=nil && id==1 {packDelta=func(entity.SyncProfile,uint64)(entity.FrozenSyncPayload,error){firstDelta();return delta,nil}}
		st:=entity.NewSubjectSyncState(entity.SubjectSyncCreateParam{Enabled:true,SubjectID:id,Namespace:"retry",Packer:entity.SubjectSyncPackFunc{
			Snapshot:func(entity.SyncProfile)(entity.FrozenSyncPayload,error){return snap,nil},
			Delta:packDelta,
		}})
		w.s[i]=st
		retryFixedOK(t,w.m.Register(st))
		for sid:=1;sid<=sessions;sid++ {if subscribed(i,sid) {retryFixedOK(t,w.m.Subscribe(SessionID(sid),id,entity.SyncProfile{Key:"view"}))}}
		st.MarkDirty(1)
	}
	return w
}

func (w *retryFixedWorld) dirty() {for _,s:=range w.s {s.MarkDirty(1)}}
func (w *retryFixedWorld) hold() {for i,s:=range w.s {w.release[i]=s.HoldSyncPublication()}}
func (w *retryFixedWorld) free(i int) {w.release[i]();w.release[i]=nil}
func (w *retryFixedWorld) freeAll() {for i,f:=range w.release {if f!=nil {w.free(i)}}}
func (w *retryFixedWorld) flush(t testing.TB) {t.Helper();retryFixedOK(t,w.m.Flush(context.Background()))}

// Observe actual retry membership and diagnostic age, never drive production from them.
// Called only at a synchronous Flush boundary. Source versions are independently checked.
func (w *retryFixedWorld) check(t testing.TB, version func(int)uint64, held func(int)bool) {
	t.Helper()
	w.m.pendingMu.Lock()
	defer w.m.pendingMu.Unlock()
	n:=0
	for i,s:=range w.s {
		id:=int64(i+1); want:=held(i)
		_,queued:=w.m.pending[id]; d,found:=w.m.deferrals[id]
		if queued!=want || found!=want || s.PendingDirty()!=want || s.Version()!=version(i) {t.Fatalf("subject=%d held=%v queued=%v deferred=%v dirty=%v version=%d want=%d",id,want,queued,found,s.PendingDirty(),s.Version(),version(i))}
		if want {
			n++
			if d.reason!="commit_pending" || d.detail!="sync commit not confirmed yet" || d.err!=nil || d.since.IsZero() || !w.first[i].IsZero() && !w.first[i].Equal(d.since) {t.Fatalf("subject %d wrong retry/first-since: %+v prior=%v",id,d,w.first[i])}
			w.first[i]=d.since
		} else {w.first[i]=time.Time{}}
	}
	if len(w.m.pending)!=n || len(w.m.deferrals)!=n {t.Fatalf("extra pending/deferrals %d/%d want %d",len(w.m.pending),len(w.m.deferrals),n)}
}

func retryFixedV(v uint64) func(int)uint64 {return func(int)uint64{return v}}
func retryFixedH(b bool) func(int)bool {return func(int)bool{return b}}

type retryFixedOp struct {op frame.ObjectOperation; version uint64}
func retryFixedCreate(v uint64)retryFixedOp{return retryFixedOp{frame.ObjectCreate,v}}
func retryFixedDelta(v uint64)retryFixedOp{return retryFixedOp{frame.ObjectUpdate,v}}

// Persist the raw bytes with explicit (round, session, frame count, payload length) boundaries,
// including silent sessions. Decoder history survives each round. Oracle names every expected
// (session, subject), independently of both packet contents and the Manager's tables.
func (w *retryFixedWorld) wire(t testing.TB, buf *bytes.Buffer, round int, oracle func(sid,id int)retryFixedOp) {
	t.Helper()
	word:=func(v uint64){var b [8]byte;binary.LittleEndian.PutUint64(b[:],v);buf.Write(b[:])}
	for sid:=1;sid<len(w.frames);sid++ {
		seen:=make([]bool,len(w.s)+1);p:=w.frames[sid];word(uint64(round));word(uint64(sid));if p==nil {word(0)} else {
			word(1);word(uint64(len(p)));buf.Write(p)
			fr,err:=w.dec[sid].Decode(p);retryFixedOK(t,err)
			w.tick[sid]++
			if fr.Tick!=w.tick[sid] || fr.BaseTick!=fr.Tick-1 || fr.Epoch!=uint32(sid) || fr.StreamID!=1 || fr.SchemaVersion!=1 || (fr.Kind==frame.Full)!=(fr.Tick==1) || len(fr.Objects)==0 {t.Fatalf("invalid/empty wire round=%d sid=%d meta=%+v kind=%v base=%d",round,sid,fr.SnapshotMeta,fr.Kind,fr.BaseTick)}
			for _,o:=range fr.Objects {
				id:=int(o.SubjectID);if id<1 || id>len(w.s) || seen[id] {t.Fatalf("round=%d sid=%d unexpected/duplicate id=%d",round,sid,id)};seen[id]=true
				want:=oracle(sid,id)
				if want.op==0 || o.Operation!=want.op {t.Fatalf("round=%d sid=%d subject=%d op=%v want=%v",round,sid,id,o.Operation,want.op)}
				if want.op==frame.ObjectRemove {if len(o.Components)!=0 {t.Fatal("remove with payload")};continue}
				if len(o.Components)!=1 {t.Fatal("expected exactly one subject component")};u:=o.Components[0].Update
				full:=want.op==frame.ObjectCreate; base:=want.version-1;prefix:=byte('D');if full {base=want.version;prefix='S'}
				if u.SubjectID!=o.SubjectID || u.Version!=want.version || u.BaseVersion!=base || u.Full!=full || u.Namespace!="retry" || u.Profile.Key!="view" || u.Payload.Codec()!=1 || !bytes.Equal(u.Payload.BytesCopy(),[]byte{prefix,byte(id)}) {t.Fatalf("round=%d sid=%d subject=%d wrong decoded full/base/version/content: %+v",round,sid,id,u)}
			}
		}
		for id:=1;id<=len(w.s);id++ {if seen[id]!=(oracle(sid,id).op!=0){t.Fatalf("round=%d sid=%d subject=%d missing/extra entry",round,sid,id)}}
	}
	clear(w.frames)
}

func retryFixedSilent(int,int)retryFixedOp{return retryFixedOp{}}

// Tiny race contract. No sleeps. ID 2 was pending in the preceding round; ID 1's
// real delta callback releases it on another goroutine before ID 2 is visited in THIS flush.
func TestM16RetryFixedReleaseOrder(t *testing.T) {
	var firstDelta func()
	w:=retryFixedNew(t,4,3,func(i,sid int)bool{return i<3 && sid<3},func(){if firstDelta!=nil {firstDelta()}})
	var raw bytes.Buffer
	round:=0; next:=func(want func(int,int)retryFixedOp){round++;w.flush(t);w.wire(t,&raw,round,want)}
	next(func(sid,id int)retryFixedOp{if sid<3 && id<=3{return retryFixedCreate(1)};return retryFixedOp{}})
	w.check(t,retryFixedV(1),retryFixedH(false))
	w.hold();extra:=w.s[2].HoldSyncPublication();defer extra();w.dirty()
	next(retryFixedSilent);w.check(t,retryFixedV(1),retryFixedH(true))
	// Held dirty publication must not suppress a known client's separate Remove.
	retryFixedOK(t,w.m.Unsubscribe(2,3));retryFixedOK(t,w.m.Subscribe(3,3,entity.SyncProfile{Key:"view"}))
	next(func(sid,id int)retryFixedOp{if sid==2&&id==3{return retryFixedOp{frame.ObjectRemove,0}};return retryFixedOp{}})
	w.check(t,retryFixedV(1),retryFixedH(true));next(retryFixedSilent);w.check(t,retryFixedV(1),retryFixedH(true))
	w.free(0);w.free(2) // one nested hold on 3 remains
	calls:=0;firstDelta=func(){calls++;done:=make(chan struct{});go func(){close(done)}();<-done}
	next(func(sid,id int)retryFixedOp{if sid<3&&id<=2{return retryFixedDelta(2)};return retryFixedOp{}})
	if calls!=1 {t.Fatalf("first-subject delta callback count=%d",calls)};firstDelta=nil
	w.check(t,func(i int)uint64{if i<2{return 2};return 1},func(i int)bool{return i>=2})
	extra();w.freeAll()
	next(func(sid,id int)retryFixedOp{if id==3 {if sid==1{return retryFixedDelta(2)};if sid==3{return retryFixedCreate(2)}};return retryFixedOp{}})
	w.check(t,retryFixedV(2),retryFixedH(false))
	next(retryFixedSilent);w.check(t,retryFixedV(2),retryFixedH(false))
	fmt.Printf("M16_RETRY_RAW rounds=%d bytes=%d raw=%x\n",round,raw.Len(),raw.Bytes())
}

const retryFixedN=64
func retryFixedShape(i,sid int,dense bool)bool {if dense{return true};switch i%8 {case 0:return sid==1;case 4:return sid<=4};return false}

type retryFixedCase struct {name string;dense,held bool}
var retryFixedCases=[]retryFixedCase{{"sparse_held",false,true},{"dense_held",true,true},{"sparse_success",false,false},{"dense_success",true,false}}
func (c retryFixedCase) world(t testing.TB)*retryFixedWorld {t.Helper();n:=4;if c.dense {n=128};return retryFixedNew(t,retryFixedN,n,func(i,sid int)bool{return retryFixedShape(i,sid,c.dense)},nil)}
func (c retryFixedCase) op(op retryFixedOp)func(int,int)retryFixedOp {return func(sid,id int)retryFixedOp{if retryFixedShape(id-1,sid,c.dense){return op};return retryFixedOp{}}}

// Bench and transcript mirror share exactly the same warmup, input and round driver.
func (c retryFixedCase) arm(w *retryFixedWorld){if c.held {w.hold();w.dirty()}}
func (c retryFixedCase) prepareRound(w *retryFixedWorld){if !c.held {w.dirty()}}

func TestM16RetryFixedShapeWire(t *testing.T) {
	for _,c:=range retryFixedCases {t.Run(c.name,func(t *testing.T){
		w:=c.world(t);var raw bytes.Buffer
		w.flush(t);w.wire(t,&raw,0,c.op(retryFixedCreate(1)));w.check(t,retryFixedV(1),retryFixedH(false));c.arm(w)
		v:=uint64(1)
		for r:=1;r<=6;r++ {c.prepareRound(w);w.flush(t);if c.held {w.wire(t,&raw,r,retryFixedSilent)} else {v++;w.wire(t,&raw,r,c.op(retryFixedDelta(v)))};w.check(t,retryFixedV(v),retryFixedH(c.held))}
		w.freeAll();w.flush(t);if c.held {v++;w.wire(t,&raw,7,c.op(retryFixedDelta(v)))} else {w.wire(t,&raw,7,retryFixedSilent)};w.check(t,retryFixedV(v),retryFixedH(false))
		w.flush(t);w.wire(t,&raw,8,retryFixedSilent);w.check(t,retryFixedV(v),retryFixedH(false))
		fmt.Printf("M16_RETRY_SHAPE %s bytes=%d sha256=%x\n",c.name,raw.Len(),sha256.Sum256(raw.Bytes()))
	})}
}

func BenchmarkM16RetryFixed(b *testing.B) {
	for _,c:=range retryFixedCases {b.Run(c.name,func(b *testing.B){
		b.StopTimer();w:=c.world(b);ctx:=context.Background();w.flush(b);clear(w.frames);c.arm(w)
		for j:=0;j<2;j++ {c.prepareRound(w);w.flush(b);clear(w.frames)}
		v:=uint64(3);if c.held {v=1};w.check(b,retryFixedV(v),retryFixedH(c.held))
		bef:=w.m.Counters();var m0,m1 runtime.MemStats;var allocs uint64
		b.ReportAllocs();b.ResetTimer()
		for j:=0;j<b.N;j++ {
			c.prepareRound(w)
			runtime.ReadMemStats(&m0)
			b.StartTimer();err:=w.m.Flush(ctx);b.StopTimer()
			runtime.ReadMemStats(&m1);allocs+=m1.Mallocs-m0.Mallocs
			retryFixedOK(b,err);clear(w.frames)
		}
		aft:=w.m.Counters();objs:=uint64(40);ss:=uint64(4);if c.dense {objs=retryFixedN*128;ss=128};captured:=uint64(retryFixedN*b.N);frames:=ss*uint64(b.N);updates:=objs*uint64(b.N)
		if c.held {captured=0;frames=0;updates=0} else {v+=uint64(b.N)}
		if aft.FlushCalls-bef.FlushCalls!=uint64(b.N) || aft.DirtyCaptured-bef.DirtyCaptured!=captured || aft.FramesAdmitted-bef.FramesAdmitted!=frames || aft.UpdatesAdmitted-bef.UpdatesAdmitted!=updates || aft.EmptyFlushes!=bef.EmptyFlushes || aft.FlushFailures!=bef.FlushFailures || aft.SessionsLost!=bef.SessionsLost || aft.CreatesAdmitted!=bef.CreatesAdmitted || aft.RemovesAdmitted!=bef.RemovesAdmitted {b.Fatalf("measured work changed: before=%+v after=%+v",bef,aft)}
		w.check(b,retryFixedV(v),retryFixedH(c.held));w.freeAll();w.flush(b);clear(w.frames);if c.held {v++};w.check(b,retryFixedV(v),retryFixedH(false))
		b.ReportMetric(float64(aft.CaptureDuration-bef.CaptureDuration)/float64(b.N),"capture-ns/op")
		b.ReportMetric(float64(aft.FlushDuration-bef.FlushDuration)/float64(b.N),"internal-flush-ns/op")
		b.ReportMetric(float64(allocs),"heap-allocs/sample")
	})}
}
