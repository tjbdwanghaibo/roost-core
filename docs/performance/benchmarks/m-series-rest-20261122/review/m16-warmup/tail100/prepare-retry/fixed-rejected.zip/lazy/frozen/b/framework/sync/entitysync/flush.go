package entitysync

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"slices"
	"time"

	"github.com/tjbdwanghaibo/roost-core/framework/entity"
	"github.com/tjbdwanghaibo/roost-core/infra/observe/metrics"
)

// markPending 把 subject 排进下一次 Flush；同时在等待快照表里的计入 pendingOverlap，统计不重复计数。
func (m *Manager) markPending(subjectID int64) {
	m.pendingMu.Lock()
	m.markPendingLocked(subjectID)
	m.pendingMu.Unlock()
}

func (m *Manager) markPendingLocked(subjectID int64) {
	if _, exists := m.pending[subjectID]; !exists {
		if _, waiting := m.waitingSnapshots[subjectID]; waiting {
			m.pendingOverlap++
		}
		m.pending[subjectID] = struct{}{}
	}
}

// takePending 取走全部待处理 subject（按 ID 升序，保证捕获顺序确定）与可能欠空 Full 的会话。
func (m *Manager) takePending() ([]int64, []SessionID) {
	m.pendingMu.Lock()
	ids := make([]int64, 0, len(m.pending))
	for id := range m.pending {
		ids = append(ids, id)
	}
	clear(m.pending)
	m.pendingOverlap = 0
	var resets []SessionID
	if len(m.resets) > 0 {
		resets = make([]SessionID, 0, len(m.resets))
		for id := range m.resets {
			resets = append(resets, id)
		}
		clear(m.resets)
	}
	m.pendingMu.Unlock()
	slices.Sort(ids)
	return ids, resets
}

// prepareResets 为仍欠空 Full、且已没有任何订阅的会话在 work 里准备一个空批次，返回这些会话。
// 还有订阅的会话丢掉登记：新 epoch 的 Full 由它们的快照兼任；之后撤到一个不剩时 removeSubscriptionLocked 会重新登记。
func (m *Manager) prepareResets(resets []SessionID, work map[SessionID]*flushSession) map[SessionID]bool {
	var owed map[SessionID]bool
	for _, sid := range resets {
		m.mu.RLock()
		sess := m.sessions[sid]
		empty := sess != nil && sess.owesEmptyFull() && len(sess.lifetime.subjects) == 0
		m.mu.RUnlock()
		if !empty {
			continue
		}
		if batch := work[sid]; batch == nil {
			work[sid] = m.takeFlushSession(sess)
		} else if batch.session != sess {
			continue // 捕获之后会话又被 Hold 或重开，交给下一次 Ready 重新登记
		}
		if owed == nil {
			owed = make(map[SessionID]bool)
		}
		owed[sid] = true
	}
	return owed
}

// ---- the tick ----

// settlement is what becomes true for one (session, subject) once the
// session's frame has been admitted.
type settlement struct {
	sub      *subscription
	revision uint64
	subj     *subject
	version  uint64
	remove   bool
	// full / codec：本项交付的是不是全量、载荷 codec；全量结算后成为会话的基线 codec（subscription.codec）。
	full  bool
	codec uint16
	// evict：本批这一项是为钉住的订阅让位而发的 remove（evictForPinned）；结算时订阅不删除，转为超额暂缓。
	evict         bool
	snapshotClass snapshotClass
}

// flushSession 集中保存同一次捕获的会话身份、帧内容与结算记录。
type flushSession struct {
	session           *session
	entries           []frameEntry
	settlements       []settlement
	snapshotAfter     snapshotMarks
	snapshotAttempted bool
}

// Flush 执行一次同步 tick：捕获 pending subject，按会话组帧并逐帧准入，最后提交内容版本。
// 同一 subject 的快照和增量在实体锁内捕获；持久化水位不足时整体暂缓该 subject。
//
// 步骤：政策阶段（applyPolicies）→ 取 pending → 逐 subject 捕获并分给会话（prepareSubscribersLocked、
// PrepareViews）→ 逐会话编码交付（pushSessionFrames）→ 提交内容版本、忘掉退役完成的 subject。
//
// ErrRetryLater（或 ctx 结束）让本轮从被拒的会话起不再推送：没有交付给全部拿到内容的会话的 subject 作废捕获、
// 保留脏状态，其余照常提交（withholdUndelivered）；已准入的会话时钟和引用继续有效，收到被作废内容的订阅在下次
// 用全量恢复基线；下一轮从被拒的会话开始轮转（rotateAfterRetry）。其他交付错误只关闭失败会话。
// flushGate 串行化整个过程，避免同一内容同时参与两次捕获。
func (m *Manager) Flush(ctx context.Context) error { return m.flush(ctx, false) }

// captureRevisionRow preserves the observed pointer identity AND its value, not its SID.
// Accessed by exactly one flushGate owner. No references escape to a sender or settlement.
type captureRevisionRow struct {
	sub *subscription
	revision uint64
}

// High-water LENGTH for this Flush. The persisted slice always has zero length and
// zeroed entries between Flushes. Use an exact transient allocation for exceptional
// fanout (configuration or pin bypass); DefaultMaxSubscribersPerSubject is a retention
// bound only and does not affect admission, subscriptions, or delivered objects.
func (m *Manager) linearRevisionsLocked(subj *subject) []captureRevisionRow {
	n := len(subj.subscribers)
	var rows []captureRevisionRow
	if n > DefaultMaxSubscribersPerSubject {
		rows = make([]captureRevisionRow, n)
	} else {
		if n > cap(m.flushRevisionRows) {
			capacity := max(n, min(2*cap(m.flushRevisionRows), DefaultMaxSubscribersPerSubject))
			m.flushRevisionRows = make([]captureRevisionRow, n, capacity)
		} else if n > len(m.flushRevisionRows) {
			m.flushRevisionRows = m.flushRevisionRows[:n]
		}
		rows = m.flushRevisionRows[:n]
	}
	i := 0
	for _, sub := range subj.subscribers {
		rows[i] = captureRevisionRow{sub:sub, revision:sub.revision}
		i++
	}
	return rows
}

func indexLinearRevisions(revisions map[*subscription]uint64, rows []captureRevisionRow) {
	clear(revisions)
	for _, row := range rows {
		revisions[row.sub] = row.revision
	}
}

func (m *Manager) releaseLinearRevisions() {
	clear(m.flushRevisionRows)
	m.flushRevisionRows = m.flushRevisionRows[:0]
}

func (m *Manager) flush(ctx context.Context, force bool) (result error) {
	if m == nil {
		return ErrManagerClosed
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if err := m.acquireFlush(ctx); err != nil {
		return err
	}
	defer m.releaseFlush()
	if m.isClosed() {
		return ErrManagerClosed
	}
	started := time.Now()
	m.flushCalls.Add(1)
	defer func() {
		// 所有已执行的失败 Flush 在一个出口记账，policy 失败也必须保留原因。
		if result != nil {
			m.flushFailures.Add(1)
			m.setLastError(result)
		}
		elapsed := time.Since(started)
		m.flushNanos.Add(uint64(elapsed))
		m.lastFlushNanos.Store(uint64(elapsed))
		metrics.ObserveHistogram("entitysync_flush_duration", nil, elapsed)
	}()
	policyStarted := time.Now()
	err := m.applyPolicies()
	m.policyNanos.Add(uint64(time.Since(policyStarted)))
	if err != nil {
		return fmt.Errorf("sync policy: %w", err)
	}
	m.refreshSnapshotWindow()
	// 仍在暂缓的订阅隔一段时间再通知政策（over_limit.go）；没有 pending 的空 Flush 也要做，所以放在这里。
	m.renotifyOverLimit()
	ids, resets := m.takePending()
	if len(ids) == 0 && len(resets) == 0 {
		m.emptyFlushes.Add(1)
		return nil
	}
	var watermark uint64
	gated := m.config.DurableWatermark != nil
	if gated {
		watermark = m.config.DurableWatermark()
	}

	prepared := make([]*entity.PreparedSubjectSync, 0, len(ids))
	preparedIDs := make([]int64, 0, len(ids)) // 与 prepared 一一对应的 subject ID
	// 常见单 profile 用一块连续存储；每会话仅持有捕获项指针。
	captures := make([]capturedUpdate, 0, len(ids))
	work := m.flushWork
	if work == nil {
		work = make(map[SessionID]*flushSession)
	}
	defer m.recycleFlush(work)
	defer releaseInFlight(work)
	defer m.publishOverLimitGauge()
	var retry []deferredSubject
	var failures []error
	type cadenceSettlement struct {
		id      int64
		cadence *subjectCadence
		state   *entity.SubjectSyncState
	}
	var cadenceSettlements []cadenceSettlement

	captureStarted := time.Now()
	plan := m.planSnapshotCaptures(ids)
	// 捕获：按 subject 获取同一版本的快照与增量，归入各会话待交付内容。
	// 修订快照只服务当前 subject；同轮复用，不按每个 subject 重建哈希表。
	var revisions map[*subscription]uint64
	defer m.releaseLinearRevisions()
	for _, id := range ids {
		subj := m.subject(id)
		if subj == nil {
			continue
		}
		subj.mu.Lock()
		// 本 subject 所在那一路的入选集合；该路不设预算时为 nil，全部快照照常捕获。
		selectedSnapshots := plan.selectedFor(m, subj.class)
		held := m.prepareSubscribersLocked(subj, work, selectedSnapshots)
		deltaProfiles, snapshotProfiles := subj.profilesLocked(selectedSnapshots)
		state := subj.state
		dirty := state.PendingDirty()
		waiting := dirty && !force && subj.cadence != nil && subj.cadence.waiting(m.cadenceTime())
		if waiting {
			m.markPending(id)
			// 窗口内只为本轮能交付的快照捕获：每次 Flush 都会重排 waiting subject，
			// 若把 Hold 会话的需求也算进来，就会每轮重打包、推进版本，并让老观察者到期时退成全量。
			snapshotProfiles = subj.deliverableSnapshotProfilesLocked(selectedSnapshots, held)
		}
		wantsCapture := len(snapshotProfiles) > 0 || dirty && !waiting
		if wantsCapture {
			lazy := subj.lastPrepareCommitPending
			// 无接收者也捕获并提交脏版本，但不为无人需要的默认视图打包。
			var rows []captureRevisionRow
			if lazy {
				rows = m.linearRevisionsLocked(subj)
			} else {
				if revisions == nil {
					revisions = make(map[*subscription]uint64)
				} else {
					clear(revisions)
				}
				for _, sub := range subj.subscribers {
					revisions[sub] = sub.revision
				}
			}
			subj.mu.Unlock()
			var item *entity.PreparedSubjectSync
			var err error
			if waiting {
				item, err = state.PrepareSnapshotViews(snapshotProfiles)
			} else {
				item, err = state.PrepareViews(deltaProfiles, snapshotProfiles)
			}
			subj.mu.Lock()
			sameState := subj.state == state
			if sameState {
				subj.lastPrepareCommitPending = false
			}
			switch {
			case errors.Is(err, entity.ErrSubjectSyncNotDirty):
			case errors.Is(err, entity.ErrSubjectSyncClosed):
				// 实体已卸载或被驱逐，内容状态随之关闭：不捕获、不重试、不算失败。订阅者保留原对象，
				// 直到 Rebind 接上重新加载的实体（强制全量）或 Unregister 发出 remove。
				// 已注销（subj.retiring）的 subject 在捕获期间关闭了状态（实体被销毁或事务内创建被撤销）
				// 也落在这里：没有内容可发，只欠后面的 ObjectRemove。
				// 接了 ManagerAccess.ConfigureUnloadResync 时，框架在卸载后主动重载或退回 remove。
			case errors.Is(err, entity.ErrSyncCommitPending):
				if sameState {
					subj.lastPrepareCommitPending = true
				}
				if m.config.Trace != nil {
					m.config.Trace.Record(SyncTraceEvent{Stage: "commit_pending", SubjectID: id})
				}
				retry = append(retry, deferredSubject{id: id, reason: "commit_pending", detail: "sync commit not confirmed yet"})
			case err != nil:
				failures = append(failures, fmt.Errorf("sync prepare subject %d: %w", id, err))
				retry = append(retry, deferredSubject{id: id, reason: "prepare_failed", err: err})
			case gated && capturedAbove(item, watermark):
				if m.config.Trace != nil {
					m.config.Trace.Record(SyncTraceEvent{Stage: "durability_wait", SubjectID: id, Version: item.Version(), CommitLSN: item.CommitLSN()})
				}
				_ = item.AbortWithError(ErrDurabilityDeferred)
				m.deferred.Add(1)
				metrics.IncCounter("entitysync_durability_gate_deferred_total", nil, 1)
				retry = append(retry, deferredSubject{id: id, reason: "durability_wait", detail: fmt.Sprintf("commit lsn %d above durable watermark %d", item.CommitLSN(), watermark)})
			default:
				dirty = item.Version() != item.BaseVersion()
				if m.config.Trace != nil {
					m.config.Trace.Record(SyncTraceEvent{Stage: "prepared", SubjectID: id, Version: item.Version(), BaseVersion: item.BaseVersion(), CommitLSN: item.CommitLSN()})
				}
				prepared = append(prepared, item)
				preparedIDs = append(preparedIDs, id)
				if !waiting && subj.cadence != nil {
					cadenceSettlements = append(cadenceSettlements, cadenceSettlement{id, subj.cadence, state})
				}
				if dirty {
					m.dirtyCaptured.Add(1)
				}
				snapshotUpdates, deltaUpdates := item.Snapshots(), item.Updates()
				m.snapshotsCaptured.Add(uint64(len(snapshotUpdates)))
				recordFullReasons(snapshotUpdates)
				recordFullReasons(deltaUpdates)
				snapshots, deltas := captureUpdates(&captures, snapshotUpdates), captureUpdates(&captures, deltaUpdates)
				if lazy {
					if revisions == nil {
						revisions = make(map[*subscription]uint64)
					}
					indexLinearRevisions(revisions, rows)
				}
				for sid, sub := range subj.subscribers {
					if held[sid] {
						continue
					}
					if work[sid] == nil || revisions[sub] != sub.revision {
						m.markPending(id)
						continue
					}
					switch sub.kind {
					case kindSnapshot:
						if sub.overLimit || selectedSnapshots != nil && !selectedSnapshots[sub] {
							continue // 超额暂缓的订阅等会话有空位（over_limit.go），同 profile 的快照是别的会话要的
						}
						if update, ok := updateFor(snapshots, sub.profile); ok {
							work[sid].entries = append(work[sid].entries, frameEntry{subjectID: id, kind: entryCreate, class: subj.class, update: update})
							work[sid].settlements = append(work[sid].settlements, captureSettlement(subj, sub, update.update))
						}
					case kindLive:
						if !dirty || waiting {
							continue
						}
						if update, ok := updateFor(deltas, sub.profile); ok {
							if m.codecMismatchLocked(subj, sid, sub, update.update) {
								continue
							}
							work[sid].entries = append(work[sid].entries, frameEntry{subjectID: id, kind: entryUpdate, class: subj.class, update: update})
							work[sid].settlements = append(work[sid].settlements, captureSettlement(subj, sub, update.update))
						}
					}
				}
			}
		}
		for sid, sub := range subj.subscribers {
			if sub.kind == kindLeaving && !held[sid] && work[sid] != nil {
				work[sid].entries = append(work[sid].entries, frameEntry{subjectID: id, kind: entryRemove, class: subj.class})
				work[sid].settlements = append(work[sid].settlements, removeSettlement(subj, sub))
			}
		}
		subj.mu.Unlock()
	}

	m.captureNanos.Add(uint64(time.Since(captureStarted)))
	// 欠空 Full 的会话在捕获之后复核：本轮捕获里新增的订阅已经登记在 lifetime 上，不会被空 Full 抢先。
	emptyFulls := m.prepareResets(resets, work)
	// 准入：会话有序处理（冷创建计费会话按计划顺序在前，其余按 ID），
	// 每帧成功后推进线协议状态，该会话全部帧成功后结算订阅。
	// 超额准入先于两种预算：只有放得下的新对象才去争发送与快照额度（over_limit.go）。
	m.admitWithinLimits(work, plan)
	sessionIDs := make([]SessionID, 0, len(work))
	for sid, batch := range work {
		if len(batch.entries) == 0 && !emptyFulls[sid] {
			continue
		}
		sessionIDs = append(sessionIDs, sid)
	}
	slices.Sort(sessionIDs)
	sessionIDs = rotateAfterRetry(sessionIDs, m.retryFrom)
	m.scheduleSends(work, time.Now())
	m.scheduleSnapshots(work, plan)
	sessionIDs = plan.admissionOrder(sessionIDs)
	defer m.commitSnapshotAttempts(work, plan)

	var admittedSessions []SessionID
	// 线上帧已交付就不能回退。传输或内容结算失败都走同一恢复边界：
	// 保留帧时钟，放弃内容捕获，并让已交付的存活订阅重建全量基线。
	retryCaptured := func(cause error) {
		abortAll(prepared, cause)
		m.requireSnapshotsAfterRetry(admittedSessions, work, nil)
		for _, id := range ids {
			m.markPending(id)
		}
		for sid := range emptyFulls {
			m.markReset(sid) // 已交付的会话复核时不再欠，自然丢掉。
		}
	}
	var admissionErr error
	var withheld map[int64]bool
	for i, sid := range sessionIDs {
		batch := work[sid]
		if batch.session == nil || m.session(sid) != batch.session {
			continue
		}
		delivered, retryErr := m.pushSessionFrames(ctx, sid, batch)
		if delivered {
			admittedSessions = append(admittedSessions, sid)
		}
		if retryErr != nil {
			// 传输此刻接不下（或 ctx 结束）：从这个会话起本轮都不再推送。只作废没能交付给全部订阅者的 subject，
			// 其余照常提交；下一轮从被拒的会话开始。
			admissionErr = fmt.Errorf("sync admission session %d: %w", sid, retryErr)
			m.retryFrom = sid
			withheld = m.withholdUndelivered(sessionIDs[i:], admittedSessions, work, emptyFulls)
			prepared, preparedIDs = abortWithheld(prepared, preparedIDs, withheld, retryErr)
			break
		}
	}
	if admissionErr == nil {
		m.retryFrom = 0
	}

	// 内容提交：提交已交付给全部订阅者的 subject 的捕获；清理退役 subject 并重排暂缓项。
	if len(prepared) > 0 {
		batch, err := entity.ReservePreparedSubjectSyncBatch(prepared)
		if err != nil {
			retryCaptured(err)
			return errors.Join(append(failures, fmt.Errorf("sync reserve: %w", err))...)
		} else if err := batch.Commit(); err != nil {
			retryCaptured(err)
			return errors.Join(append(failures, fmt.Errorf("sync commit: %w", err))...)
		}
	}
	for _, settle := range cadenceSettlements {
		if !withheld[settle.id] {
			settle.cadence.settled(settle.state, m.cadenceTime())
		}
	}
	if withheld != nil {
		// 被作废的 subject 保留脏状态与等待状态，下一轮重新捕获；不算本轮处理完。
		ids = slices.DeleteFunc(slices.Clone(ids), func(id int64) bool { return withheld[id] })
	}
	for _, id := range ids {
		subj := m.subject(id)
		if subj == nil {
			continue
		}
		subj.mu.Lock()
		done := subj.retiring && len(subj.subscribers) == 0
		m.clearSnapshotWaitLocked(subj)
		subj.mu.Unlock()
		if done {
			m.forget(subj)
		}
	}
	m.settleDeferrals(ids, retry)
	if admissionErr != nil {
		failures = append(failures, admissionErr)
	}
	return errors.Join(failures...)
}

// rotateAfterRetry 让上一轮被拒（ErrRetryLater）之后的这一轮从被拒的会话开始按 ID 轮转：sessionIDs 已升序，
// 返回从第一个不小于 from 的 ID 开始、绕回开头的顺序；from 为 0（上一轮没有被拒）时原样返回。
// 冷创建计费的会话仍由 admissionOrder 按计划排在最前（它们有自己的游标），这里只决定其余会话的先后。
func rotateAfterRetry(sessionIDs []SessionID, from SessionID) []SessionID {
	if from == 0 || len(sessionIDs) < 2 {
		return sessionIDs
	}
	start, _ := slices.BinarySearch(sessionIDs, from)
	if start == 0 || start == len(sessionIDs) {
		return sessionIDs
	}
	rotated := make([]SessionID, 0, len(sessionIDs))
	rotated = append(rotated, sessionIDs[start:]...)
	return append(rotated, sessionIDs[:start]...)
}

// withholdUndelivered 处理本轮在 unreached[0] 处被传输拒收（ErrRetryLater）或 ctx 结束：unreached 是被拒的会话
// 及其后本轮没有尝试的会话。它们本轮内容里的 subject 没有交付给全部订阅者，返回这些 subject（不提交、保留脏状态，
// 下一轮重新捕获）；其余 subject 已交付给每个拿到它内容的会话，照常提交。
//
// 已经收到被作废 subject 内容的会话（被拒会话已准入的前几帧、之前完整交付的会话）手里的版本不会提交，
// 这些订阅改为下一轮收全量（requireSnapshotsAfterRetry）；没收到的会话订阅不动，下一轮的增量仍从它们持有的基线算起。
// 被拒及之后的会话欠的空全量重新登记。调用方在提交之前调用，flushGate 内。
func (m *Manager) withholdUndelivered(unreached, admitted []SessionID, work map[SessionID]*flushSession, emptyFulls map[SessionID]bool) map[int64]bool {
	withheld := make(map[int64]bool)
	for _, sid := range unreached {
		for _, settle := range work[sid].settlements {
			withheld[settle.subj.id] = true
		}
		if emptyFulls[sid] {
			m.markReset(sid)
		}
	}
	m.requireSnapshotsAfterRetry(admitted, work, withheld)
	for id := range withheld {
		m.markPending(id)
	}
	return withheld
}

// abortWithheld 中止被作废 subject 的捕获，返回剩下要提交的捕获（与 ids 一一对应）。
func abortWithheld(prepared []*entity.PreparedSubjectSync, ids []int64, withheld map[int64]bool, cause error) ([]*entity.PreparedSubjectSync, []int64) {
	kept, keptIDs := prepared[:0], ids[:0]
	for i, item := range prepared {
		if withheld[ids[i]] {
			_ = item.AbortWithError(cause)
			continue
		}
		kept, keptIDs = append(kept, item), append(keptIDs, ids[i])
	}
	return kept, keptIDs
}

// prepareSubscribersLocked 为本轮整理 subject 的订阅者，返回本 tick 要跳过的会话（无则 nil）：
// 会话已关闭或已换 lifetime 的订阅直接移除（不再欠任何内容）；held 会话，以及本轮 work 里已由
// 同 ID 另一个会话状态占用的会话，本 tick 跳过（ReadySession 会重新调度）；其余会话在 work 中
// 取得本轮的 flushSession，并在冷创建预算生效时处理未入选的全量。调用方持有 subj.mu。
func (m *Manager) prepareSubscribersLocked(subj *subject, work map[SessionID]*flushSession, selected map[*subscription]bool) map[SessionID]bool {
	var held map[SessionID]bool
	var deferred uint64
	hold := func(sid SessionID) {
		if held == nil {
			held = make(map[SessionID]bool)
		}
		held[sid] = true
	}
	for sid, sub := range subj.subscribers {
		captured := work[sid]
		var sess *session
		if m.config.Trace == nil && captured != nil && captured.session != nil && captured.session.lifetime == sub.lifetime && sub.lifetime.published.Load() == captured.session {
			// Same immutable state, this lifetime, observed NOW. Holding work alone is never enough; nil/mismatch
			// goes back to the original locked read, including old-lifetime cleanup and same-SID replacement.
			sess = captured.session
		} else {
			sess = m.session(sid)
		}
		switch {
		case sess == nil || sess.lifetime != sub.lifetime:
			m.removeSubscriptionLocked(subj, sid)
			continue
		case sess.held:
			hold(sid)
			continue
		}
		if captured == nil {
			work[sid] = m.takeFlushSession(sess)
		} else if captured.session != sess {
			hold(sid)
			continue
		}
		if selected != nil && sub.kind == kindSnapshot && !sub.overLimit && !selected[sub] {
			// 已有引用的视图替换仍是一次对象更新，不占冷创建额度。
			if _, exists := sess.objects[subj.id]; exists {
				selected[sub] = true
			} else {
				deferred++
			}
		}
	}
	if deferred != 0 {
		// 失效 lifetime 的清理可能撤销旧等待项。全部清完才登记，本 subject 一次，计数仍按订阅。
		m.deferSnapshot(subj)
		m.snapshotsDeferred.Add(deferred)
	}
	return held
}

// pushSessionFrames 编码一个会话本轮的内容并逐帧交付：每帧准入后立即采纳该帧的会话时钟与引用表，
// 全部帧成功（且会话状态未被替换）后结算订阅。delivered 表示至少一帧已准入。retryErr 非 nil 表示
// 本轮要停下重试（ErrRetryLater 或 ctx 结束），由调用方作废没交付到的捕获（withholdUndelivered）；其他编码或交付错误只关闭本会话，
// 经 SessionLost 交出带分类的原因（SessionLoss：推送拒收 / 编码失败的几类）。
func (m *Manager) pushSessionFrames(ctx context.Context, sid SessionID, batch *flushSession) (delivered bool, retryErr error) {
	sess := batch.session
	encodeStarted := time.Now()
	if m.config.Trace != nil {
		m.traceSelectedEntries(sid, sess, batch.entries)
	}
	// 编码只改副本；每一帧准入后分别采纳其时钟与引用表。
	// 后一帧或另一会话失败时，已成功交付的前缀不能回滚。
	next := sess.clone()
	next.snapshotAfter = batch.snapshotAfter
	payloads, err := next.encode(batch.entries, m.wire, &m.encodeWork)
	if m.config.Trace != nil {
		if err != nil {
			m.config.Trace.Record(SyncTraceEvent{Stage: "encode_failed", Session: sid, Lifetime: sess.lifetime.traceID, Epoch: sess.epoch, Duration: time.Since(encodeStarted)})
		}
		for _, encoded := range payloads {
			m.config.Trace.Record(SyncTraceEvent{Stage: "encoded", Session: sid, Lifetime: sess.lifetime.traceID, Epoch: encoded.next.epoch, Tick: encoded.next.tick, Duration: time.Since(encodeStarted)})
		}
	}
	m.encodeNanos.Add(uint64(time.Since(encodeStarted)))
	if err != nil {
		// 帧没有交给传输：连接没有拒收任何东西，原因按编码错误归类（SessionLossReason），由接入层决定断开连接。
		m.loseSession(sess, encodeLoss(err))
		return false, nil
	}
	var pushErr error
	stale := false
	for i, encoded := range payloads {
		if m.session(sid) != sess {
			stale = true
			break
		}
		if err := ctx.Err(); err != nil {
			pushErr = err
			break
		}
		admissionStarted := time.Now()
		batch.snapshotAttempted = true
		if m.config.SendBudget.MaxBytes > 0 {
			// 按实际尝试的完整帧计费；未尝试、编码失败、旧连接不预扣。
			sess.lifetime.sendBytes += len(encoded.payload)
		}
		pushErr = m.config.Transport.Push(ctx, sid, encoded.payload)
		if m.config.Trace != nil {
			stage := "admitted"
			if pushErr != nil {
				stage = "admission_failed"
			}
			m.config.Trace.Record(SyncTraceEvent{Stage: stage, Session: sid, Lifetime: sess.lifetime.traceID, Epoch: encoded.next.epoch, Tick: encoded.next.tick, Duration: time.Since(admissionStarted)})
		}
		m.admissionNanos.Add(uint64(time.Since(admissionStarted)))
		if pushErr != nil {
			break
		}
		adopted := m.adoptSession(sess, encoded.next)
		if i == 0 {
			delivered = true
		}
		m.framesAdmitted.Add(1)
		m.createsAdmitted.Add(encoded.creates)
		m.updatesAdmitted.Add(encoded.updates)
		m.removesAdmitted.Add(encoded.removes)
		metrics.IncCounter("entitysync_frames_admitted_total", nil, 1)
		if !adopted {
			stale = true
			break
		}
		sess = encoded.next
	}
	if ctx.Err() != nil && pushErr != nil {
		pushErr = ctx.Err()
	}
	if errors.Is(pushErr, ErrRetryLater) || (pushErr != nil && ctx.Err() != nil) {
		return delivered, pushErr
	}
	if pushErr != nil {
		m.loseSession(sess, &SessionLoss{Reason: SessionLossPushRefused, Err: pushErr})
		return delivered, nil
	}
	if !stale {
		m.settleSubscriptions(sid, batch.settlements)
		m.releaseOverLimit(sid, sess)
	}
	return delivered, nil
}

// traceSelectedEntries 记录本轮为会话选中的每个内容项；只在启用 Trace 时调用。
func (m *Manager) traceSelectedEntries(sid SessionID, sess *session, entries []frameEntry) {
	for _, entry := range entries {
		if entry.update == nil {
			continue
		}
		u := entry.update.update
		m.config.Trace.Record(SyncTraceEvent{Stage: "selected", SubjectID: entry.subjectID, Session: sid, Lifetime: sess.lifetime.traceID, Epoch: sess.epoch, Version: u.Version, BaseVersion: u.BaseVersion, Full: u.Full, Reason: uint8(u.Reason), Snapshot: entry.kind == entryCreate})
	}
}

// captureSettlement 在 subject 锁内记录本轮交付一份更新对应的意图：结算后会话持有 update.Version；
// update 是全量时，会话的基线 codec 换成它的载荷 codec（见 subscription.codec）。
func captureSettlement(subj *subject, sub *subscription, update entity.SubjectSyncUpdate) settlement {
	sub.inFlight = true
	return settlement{subj: subj, sub: sub, revision: sub.revision, version: update.Version, full: update.Full, codec: update.Payload.Codec(), snapshotClass: sub.snapshotClass}
}

// removeSettlement 在 subject 锁内记录本轮发出 remove 对应的意图。
func removeSettlement(subj *subject, sub *subscription) settlement {
	sub.inFlight = true
	return settlement{subj: subj, sub: sub, revision: sub.revision, remove: true, snapshotClass: sub.snapshotClass}
}

// evictSettlement 在 subject 锁内记录“为钉住的订阅让位”发出 remove 的意图（over_limit.go evictForPinned）。
func evictSettlement(subj *subject, sub *subscription) settlement {
	sub.inFlight = true
	return settlement{subj: subj, sub: sub, revision: sub.revision, evict: true, snapshotClass: sub.snapshotClass}
}

// codecMetric 计“增量的 codec 与会话基线不同、改发全量”的次数；namespace 标签是 subject 的同步命名空间（随实体类型
// 有限，不含实体或会话身份）。
const codecMetric = "entitysync_codec_resyncs_total"

// codecMismatchLocked 守住线格式 v3 的前提“增量沿用基线全量的 codec”（docs/framework/ENTITY_SYNC.md“线格式”）：
// 一份非空的非全量更新，载荷 codec 与会话持有的基线不同时，接收端会按基线的 codec 去解它——可能解错而不报错。
// 这时不发这份增量：订阅转回待快照（基线作废），subject 排进下一次 Flush，会话收到当前状态的全量（Reason = Resync，
// 带新 codec），之后的增量按新 codec 解。只影响基线 codec 不符的会话；同一份增量照常发给基线已是新 codec 的会话。
// 空载荷的增量不带字节、codec 无关，照常发出。返回 true 表示已拒绝这份增量。调用方持有 subj.mu。
func (m *Manager) codecMismatchLocked(subj *subject, sid SessionID, sub *subscription, update entity.SubjectSyncUpdate) bool {
	if update.Full || update.Payload.Len() == 0 || update.Payload.Codec() == sub.codec {
		return false
	}
	namespace := subj.state.Namespace()
	m.codecResyncs.Add(1)
	metrics.IncCounter(codecMetric, metrics.Labels{"namespace": namespace}, 1)
	if ok, suppressed := m.codecWarn.take(time.Now()); ok {
		// 限频（每个 Manager 10 秒至多一条，与超额降级同一闸门实现）：自定义 packer 换 codec 是编程问题，不是负载。
		slog.Warn("entitysync: a delta's codec differs from the session's baseline; sending a full instead",
			"manager", m.config.Name, "namespace", namespace, "subject", subj.id, "session", sid,
			"baseline_codec", sub.codec, "delta_codec", update.Payload.Codec(), "suppressed", suppressed)
	}
	sub.baseVersion = 0
	sub.sendWaiting = time.Time{}
	m.changeSubscriptionKindLocked(subj, sid, sub, kindSnapshot)
	if sess := m.session(sid); sess != nil {
		m.traceSnapshotRequest(subj, sess)
	}
	m.markPending(subj.id)
	m.WakeSync()
	return true
}

func releaseInFlight(work map[SessionID]*flushSession) {
	for _, batch := range work {
		for _, entry := range batch.settlements {
			entry.subj.mu.Lock()
			entry.sub.inFlight = false
			entry.subj.mu.Unlock()
		}
	}
}

// requireSnapshotsAfterRetry 为已收到本轮内容、但内容捕获被作废的会话重新建立全量基线：only 为 nil 时作废的是
// 本轮全部捕获，否则只处理 only 里的 subject。remove 仍按原意结算；已交付的会话时钟和引用表不在这里回滚。
func (m *Manager) requireSnapshotsAfterRetry(admittedSessions []SessionID, work map[SessionID]*flushSession, only map[int64]bool) {
	for _, admitted := range admittedSessions {
		for _, settle := range work[admitted].settlements {
			if settle.remove || only != nil && !only[settle.subj.id] {
				continue
			}
			settle.subj.mu.Lock()
			if sub := settle.subj.subscribers[admitted]; sub == settle.sub && sub.kind != kindLeaving {
				sub.baseVersion = 0
				m.changeSubscriptionKindLocked(settle.subj, admitted, sub, kindSnapshot)
				settle.subj.profilesValid = false
				m.traceSnapshotRequest(settle.subj, work[admitted].session)
			}
			settle.subj.mu.Unlock()
		}
	}
}

// settleSubscriptions 在当前会话的全部帧准入后更新订阅意图；
// 编码和传输期间已经删除的订阅不会在这里重新创建。
func (m *Manager) settleSubscriptions(sid SessionID, settlements []settlement) {
	for _, settle := range settlements {
		settle.subj.mu.Lock()
		if sub := settle.subj.subscribers[sid]; sub == settle.sub && sub.revision == settle.revision {
			if settle.remove {
				m.removeSubscriptionLocked(settle.subj, sid)
			} else if settle.evict {
				// 为钉住的订阅让位：对象已从客户端移除，订阅保持，转为超额暂缓等空位（over_limit.go）。
				sub.baseVersion = 0
				sub.sendWaiting = time.Time{}
				sub.snapshotClass = snapshotArrival
				m.changeSubscriptionKindLocked(settle.subj, sid, sub, kindSnapshot)
				m.markOverLimitLocked(settle.subj, sid, sub, true)
			} else {
				if sub.kind != kindLive {
					settle.subj.profilesValid = false
				}
				sub.baseVersion = settle.version
				if settle.full {
					sub.codec = settle.codec
				}
				sub.sendWaiting = time.Time{}
				m.changeSubscriptionKindLocked(settle.subj, sid, sub, kindLive)
				sub.snapshotClass = snapshotArrival
			}
		}
		settle.subj.mu.Unlock()
	}
}

// capturedAbove reports whether any part of the capture came from a commit
// the durable watermark has not reached.
func capturedAbove(item *entity.PreparedSubjectSync, watermark uint64) bool {
	return item.CommitLSN() > watermark
}

func abortAll(prepared []*entity.PreparedSubjectSync, cause error) {
	for _, item := range prepared {
		_ = item.AbortWithError(cause)
	}
}

// recordFullReasons 按原因计数全量捕获。标签集合固定：不以实体、会话或业务提供的 reason 数值制造无限监控序列。
func recordFullReasons(updates []entity.SubjectSyncUpdate) {
	for _, update := range updates {
		if !update.Full {
			continue
		}
		reason := "other"
		switch update.Reason {
		case entity.SyncFullReasonDirty:
			reason = "dirty"
		case entity.SyncFullReasonResync:
			reason = "resync"
		case entity.SyncFullReasonSchema:
			reason = "schema"
		}
		metrics.IncCounter("entitysync_full_captures_total", metrics.Labels{"reason": reason}, 1)
	}
}
