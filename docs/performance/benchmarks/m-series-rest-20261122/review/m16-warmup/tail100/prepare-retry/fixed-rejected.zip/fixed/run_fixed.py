"""Explicit parent-only launch. A: contracts + killed test-only negative control. Pair: one selected B, four serial legs. No services."""
import fcntl, json, os, re, signal, subprocess as sp, sys, time
from pathlib import Path
from gate import TAGS, contract, need, score, select, sha

F=Path(__file__).resolve().parent; W=Path(os.environ['MESHY_WORK']).resolve();R=Path(os.environ['MESHY_PROJECT']).resolve()/'.claude/worktrees/main-review-fixes';E=Path('framework/sync/entitysync');K=str(R/E/'m16_retry_fixed_test.go');H='24b704bf1627d4db3f64c4f87880bfce808af326';P=W/'m16-rev-slot/prod-a';G=F/'retry_fixed_test.go';A=json.loads((P/'overlay.json').read_text())['Replace'];sys.path.insert(0,str(W/'m16-rev-slot/c4'));from wrapper import isolation,clear,stop_group
ENV={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL','LC_CTYPE','TZ') if k in os.environ};ENV.update(GOWORK='off',GOPROXY='off',GOSUMDB='off',GOFLAGS='-p=2',GOMAXPROCS='2',GOTOOLCHAIN='local',PYTHONDONTWRITEBYTECODE='1')

def load(p):return json.loads(Path(p).read_bytes())
def save(p,obj):
    with p.open('x') as f:json.dump(obj,f,indent=2,ensure_ascii=False);f.write('\n')
def pinned():
    need(F==W/'m16-prepare-retry/fixed','wrong location');pins=load(F/'pins.json');need(all(sha(F/n)==v for n,v in pins['fixed'].items()),'frozen files changed');need(all(A[str(R/E/n)]==str(P/E/n) and sha(P/E/n)==v for n,v in pins['product_A'].items()) and len(A)==4,'wrong product A');need(load(F/'overlay.json')['Replace']==(A|{K:str(G)}),'wrong A overlay');need(not Path(K).exists(),'test key shadows real file');need(sp.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==H,'wrong HEAD');need(not sp.check_output(['git','status','--porcelain','--untracked-files=all','--','framework','codegen','go.mod','go.sum'],cwd=R),'dirty package/module inputs')

def launch(out,tag,args,guard,neg=False):
    bef=isolation('before '+tag);clear(bef);snaps=[bef];p=None
    with (out/(tag+'.log')).open('x') as log:
        print('+',tag,*(str(a) for a in args),flush=True)
        p=sp.Popen(args,cwd=R,env=ENV,stdout=log,stderr=sp.STDOUT,start_new_session=True,pass_fds=(guard.fileno(),))
        try:
            while True:
                try:rc=p.wait(timeout=10);break
                except sp.TimeoutExpired:snaps.append(isolation('during '+tag,p.pid));clear(snaps[-1])
        except BaseException:stop_group(p);raise
    snaps.append(isolation('after '+tag));clear(snaps[-1]);save(out/(tag+'.exit.json'),dict(argv=list(map(str,args)),exit=rc,isolation=snaps));s=(out/(tag+'.log')).read_text()
    if neg:need(rc==1 and 'round=5 sid=1 subject=2 missing/extra entry' in s and '--- FAIL: TestM16RetryFixedReleaseOrder' in s and 'DATA RACE' not in s,'negative did not die at release-order oracle')
    else:need(rc==0,'failed: '+tag)
    return s

def side(out,tag,repl,g):
    pkg='./'+str(E);ov=out/(tag+'.overlay.json');save(ov,{'Replace':repl|{K:str(G)}});base=['go','test','-mod=readonly','-overlay',ov];tiny=launch(out,tag+'-tiny',base+['-race','-count=3','-timeout=90s','-run','^TestM16RetryFixedReleaseOrder$','-v',pkg],g);contract(tiny,'tiny',3)
    shape=launch(out,tag+'-shape',base+['-count=3','-timeout=120s','-run','^TestM16RetryFixedShapeWire$','-v',pkg],g);contract(shape,'shape',3)
    return base

def negative(out,g):
    # Test driver only; do NOT change the product or the oracle. Suppress just ID 2's release.
    s=G.read_text();old='w.free(1);close(done)';need(s.count(old)==1,'negative edit anchor changed');k=out/'withheld_test.go';k.write_text(s.replace(old,'close(done)'));ov=out/'withheld.overlay.json';save(ov,{'Replace':A|{K:str(k)}});launch(out,'negative',['go','test','-mod=readonly','-overlay',ov,'-race','-count=1','-timeout=60s','-run','^TestM16RetryFixedReleaseOrder$','-v','./'+str(E)],g,True)

def run():
    a=sys.argv[1:];need(len(a)==2 and a[0]=='a' or len(a)==5 and a[0]=='pair','usage: run_fixed.py a NEW_OUT | pair NEW_OUT PRODUCT_B_OVERLAY SELECTION_JSON ORIGINAL_A_TRACE_GZ');out=Path(a[1]).resolve();need(out.is_relative_to(W) and not out.is_relative_to(F) and not out.exists(),'new private result directory required, outside frozen input')
    def stop(*_):raise KeyboardInterrupt('stopped')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGHUP,stop)
    with (W/'m-series-fixes/measure.lock').open('r+b') as g:
        fcntl.flock(g,fcntl.LOCK_EX|fcntl.LOCK_NB);clear(isolation('locked'));pinned();out.mkdir(mode=0o700);src={'a':dict(A)}
        if a[0]=='pair':
            ov,sel,tr=map(lambda x:Path(x).resolve(),a[2:]);decision=load(sel);tr0=W/'m16-prepare-retry/c4/trace.json.gz';need(tr==tr0 and decision==select(tr) and decision['eligible'] and load(tr.parent/'stock.json')['trace']==decision['trace_sha256'],'need preselected actual, validated, original-A evidence, not benchmark choice');save(out/'selection.json',decision)
            # Only a product override of existing .go files in entity/entitysync. No generated meter or test helpers.
            extras=load(ov)['Replace'];need(bool(extras),'missing selected B');repl=dict(A);diff=[]
            for k,v in extras.items():
                key=Path(k);v=Path(v).resolve();need(key==key.resolve() and key.is_file() and key.suffix=='.go' and not key.name.endswith('_test.go') and (key.parent==R/E or key.parent==R/'framework/entity') and v.is_file(),'not a product-only candidate key: '+k);repl[k]=str(v)
                if sha(v)!=sha(A.get(k,k)):diff.append(str(key.relative_to(R)))
            need(diff,'candidate has no product diff');src['b']=repl;save(out/'selected-product.json',dict(overlay_sha256=sha(ov),changed=sorted(diff),effective_sha256={k:sha(v) for k,v in repl.items()}))
        version=launch(out,'runtime',['go','version'],g).strip();save(out/'inputs.json',dict(head=H,pins_sha256=sha(F/'pins.json'),go=version,order=TAGS if a[0]=='pair' else [],n=32,count=5,primary_metric='ns/op',seed='64 objects; sparse 0/1/4, dense 128; one hold per object; all successful control'))
        binaries={};hashes={};source_hashes={tag:{k:sha(v) for k,v in paths.items()} for tag,paths in src.items()}
        for tag,repl in src.items():
            base=side(out,tag,repl,g)
            if tag=='a':negative(out,g)
            if a[0]=='pair':
                binaries[tag]=out/(tag+'.test');launch(out,tag+'-build',base+['-c','-o',binaries[tag],'./'+str(E)],g);hashes[tag]=sha(binaries[tag])
        if a[0]=='a':save(out/'checked.json',dict(pass_A_contracts=True,negative_control_killed=True));return
        need(hashes['a']!=hashes['b'],'identical binaries');save(out/'binaries.json',hashes)
        for kind in ('tiny','shape'):need(contract((out/('a-'+kind+'.log')).read_text(),kind,3)==contract((out/('b-'+kind+'.log')).read_text(),kind,3),'A/B wire mismatch before benchmarking')
        for tag in TAGS:
            s=tag[0];need(sha(binaries[s])==hashes[s],'binary changed');launch(out,tag,[binaries[s],'-test.run=^$','-test.bench=^BenchmarkM16RetryFixed$','-test.benchmem','-test.benchtime=32x','-test.count=5','-test.cpu=2','-test.timeout=180s'],g)
        pinned();need(all(sha(v)==source_hashes[tag][k] for tag,paths in src.items() for k,v in paths.items()),'changed product inputs');z=score(out,decision['primary']);save(out/'gate.json',z);print('PASS' if z['pass'] else 'STOP',flush=True);need(z['pass'],'fixed gate failed; do not advance')

if __name__=='__main__':run()
