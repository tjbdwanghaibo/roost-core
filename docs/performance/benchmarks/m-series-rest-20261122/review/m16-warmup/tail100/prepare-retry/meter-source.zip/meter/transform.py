"""M16 prepare meter. Pure copy-on-transform of effective, repo-relative sources.
Main input is the frozen tail100 A overlay (NOT sweep). See schema.json.
"""
from pathlib import Path
import hashlib, os

HERE = Path(__file__).resolve().parent
E = 'framework/entity/'
S = 'framework/sync/entitysync/'
SUB = E+'subject_sync.go'; FL = S+'flush.go'; GAP = S+'m16_gap.go'; DR = S+'drain.go'

def one(s, old, new):
    if s.count(old) != 1:
        raise ValueError('unexpected source, expected unique anchor: '+repr(old[:150]))
    return s.replace(old,new)

OBS = '''
// Diagnostic overlay only. Reuse one instance for sequential visits under flushGate.
// No registration or lookup by subject; nil takes no clock. Production clock and
// end-of-object clock share the existing M16Gap origin, with Go monotonic readings.
type M16PrepareObservation struct {
    Origin time.Time
    Cuts [17]int64
    Seen uint32
    Result uint16
    Holds int
    afterCut func(int) // nil except deterministic lock-boundary unit contracts
}
func (o *M16PrepareObservation) Mark(k int) {
    if o != nil {
        o.Cuts[k] = time.Since(o.Origin).Nanoseconds()
        o.Seen |= 1<<k
        if o.afterCut != nil { o.afterCut(k) }
    }
}
func (o *M16PrepareObservation) decide(result uint16) {
    if o != nil { o.Result = result; o.Mark(12) }
}
'''

def subject(s):
    s = one(s, 'type subjectSyncLockFunc ', OBS+'\ntype subjectSyncLockFunc ')
    s = one(s,'func (s *SubjectSyncState) withEntityLock(fn func() error) error {','func (s *SubjectSyncState) withEntityLock(o *M16PrepareObservation, fn func() error) error {')
    s = one(s,'s.mu.Lock()\n\tlockEntity := s.lockEntity\n\ts.mu.Unlock()', 'o.Mark(5)\n\ts.mu.Lock()\n\to.Mark(6)\n\tlockEntity := s.lockEntity\n\ts.mu.Unlock()\n\to.Mark(7)')
    sig='func (s *SubjectSyncState) PrepareViews(deltaProfiles, snapshotProfiles []SyncProfile) (*PreparedSubjectSync, error) {'
    s = one(s,sig,sig+'\nreturn s.M16PrepareViews(nil, deltaProfiles,snapshotProfiles)\n}\n'+sig.replace('PrepareViews(deltaProfiles','M16PrepareViews(o *M16PrepareObservation, deltaProfiles'))
    s = one(s, 'return s.prepareProfiles(NormalizeSyncProfiles(', 'return s.prepareProfiles(o, NormalizeSyncProfiles(')
    sig='func (s *SubjectSyncState) PrepareSnapshotViews(profiles []SyncProfile) (*PreparedSubjectSync, error) {'
    s = one(s,sig,sig+'\nreturn s.M16PrepareSnapshotViews(nil,profiles)\n}\n'+sig.replace('PrepareSnapshotViews(profiles','M16PrepareSnapshotViews(o *M16PrepareObservation, profiles'))
    s = one(s,'item, err := s.PrepareViews(nil, profiles)','item, err := s.M16PrepareViews(o, nil, profiles)')
    nilbody='if s == nil {\n\t\treturn nil, ErrSubjectSyncClosed'
    for sig in ['M16PrepareViews(o *M16PrepareObservation, deltaProfiles, snapshotProfiles []SyncProfile)', 'M16PrepareSnapshotViews(o *M16PrepareObservation, profiles []SyncProfile)']:
        a=sig+' (*PreparedSubjectSync, error) {\n\t'+nilbody
        s=one(s,a,a.replace('return nil, Err','if o != nil { o.Result=4 }; return nil, Err'))
    s=one(s,'func (s *SubjectSyncState) prepareProfiles(deltaProfiles','func (s *SubjectSyncState) prepareProfiles(o *M16PrepareObservation, deltaProfiles')
    s=one(s,'s.withEntityLock(func() error {\n\t\ts.prepareMu.Lock()', 's.withEntityLock(o, func() error {\n\t\to.Mark(8)\n\t\ts.prepareMu.Lock()\n\t\to.Mark(9)')
    s=one(s,'prepared, err = s.prepareLocked(deltaProfiles, snapshotProfiles)','prepared, err = s.m16PrepareLocked(o,deltaProfiles, snapshotProfiles)\n\t\to.Mark(13)')
    sig='func (s *SubjectSyncState) prepareLocked(deltaProfiles, snapshotProfiles []SyncProfile) (*PreparedSubjectSync, error) {'
    s=one(s,sig,sig+'\nreturn s.m16PrepareLocked(nil,deltaProfiles,snapshotProfiles)\n}\n'+sig.replace('prepareLocked(deltaProfiles','m16PrepareLocked(o *M16PrepareObservation,deltaProfiles')+'\no.Mark(10)')
    s=one(s,'if s.policyHolds != 0 || !s.commitGate.ready() {','''o.Mark(11)
    if s.policyHolds != 0 {
        if o != nil { o.Holds = s.policyHolds; o.decide(1) }
        s.mu.Unlock()
        return nil, ErrSyncCommitPending
    } else if !s.commitGate.ready() {
        o.decide(2)''')
    for old, new in [ ('if !s.enabled {\n\t\ts.mu.Unlock()\n\t\treturn nil, ErrSubjectSyncClosed','if !s.enabled {\n o.decide(4)\n\t\ts.mu.Unlock()\n\t\treturn nil, ErrSubjectSyncClosed'),('s.mu.Unlock()\n\t\t\treturn nil, ErrSubjectSyncInFlight','o.decide(9)\n s.mu.Unlock()\n\t\t\treturn nil, ErrSubjectSyncInFlight'),('if !dirty && len(snapshotProfiles) == 0 {','if !dirty && len(snapshotProfiles) == 0 {\n o.decide(3)'),('if s.packer == nil {\n\t\ts.lastError','if s.packer == nil {\n o.decide(5)\n\t\ts.lastError'),('s.nextToken++','if o != nil { if dirty { o.decide(8) } else { o.decide(7) } }\n s.nextToken++') ]:
        s=one(s,old,new)
    if s.count('s.failPrepare(token, err)')!=2: raise ValueError('packer error anchors changed')
    return s.replace('s.failPrepare(token, err)','if o != nil { o.Result = 6 }; s.failPrepare(token, err)')

COST = '''
// All append-only public rows are owned by this flush until gap.publish.
// Index for settle is carried by the actual deferredSubject, not looked up in a map.
func (r *m16GapRound) meterVisit(o *entity.M16PrepareObservation, begin,end int64, flags uint16, copied int) {
    k := o.Result
    r.w.MeterCodes = append(r.w.MeterCodes, flags|k)
    idx := r.meterIndex[k]
    if idx == 0 {
        r.w.MeterCosts = append(r.w.MeterCosts, [24]int64{int64(k)})
        idx = uint8(len(r.w.MeterCosts)); r.meterIndex[k] = idx
    }
    a := &r.w.MeterCosts[idx-1]
    a[1]++; a[2]+=int64(copied); a[3]+=int64(o.Holds); a[4]=max(a[4],int64(o.Holds)); a[5]+=end-begin
    a[7]+=o.Cuts[1]-begin; a[8]+=o.Cuts[2]-o.Cuts[1]
    if k==0 { a[23]+=end-o.Cuts[2]; return }
    a[9]+=o.Cuts[3]-o.Cuts[2]; a[10]+=o.Cuts[4]-o.Cuts[3]
    a[6]+=o.Cuts[14]-o.Cuts[4]
    prev:=4
    for j:=5;j<=14;j++ {
        if o.Seen&(1<<j)==0 {continue}; col:=j+6
        if prev+1!=j {col=21} // unentered callback/early API error: do not invent intermediate clocks
        a[col]+=o.Cuts[j]-o.Cuts[prev]; prev=j
    }
    a[22]+=o.Cuts[15]-o.Cuts[14]; a[23]+=end-o.Cuts[15]
}
'''

def gap(s):
    s=one(s,'type m16GapWork struct {','''type m16GapWork struct {
    MeterCodes []uint16 `json:"meter_codes,omitempty"`
    MeterCosts [][24]int64 `json:"meter_costs,omitempty"`
    MeterRetryAll bool `json:"meter_retry_all,omitempty"`''')
    s=one(s,'type m16GapRound struct {','type m16GapRound struct {\n meterIndex [11]uint8')
    s=one(s,'w.Objects = slices.Clone(r.w.Objects)','w.Objects = slices.Clone(r.w.Objects)\n w.MeterCodes=slices.Clone(r.w.MeterCodes); w.MeterCosts=slices.Clone(r.w.MeterCosts)')
    return s+'\n'+COST

def flush(s):
    s=one(s,'func (m *Manager) markPendingLocked(subjectID int64) {','func (m *Manager) markPendingLocked(subjectID int64) bool {')
    s=one(s,'m.pending[subjectID] = struct{}{}\n\t}\n}', 'm.pending[subjectID] = struct{}{}\nreturn true\n\t}\nreturn false\n}')
    s=one(s,'gap.w.Objects = make([][5]int64, 0, len(ids))','gap.w.Objects = make([][5]int64, 0, len(ids))\n gap.w.MeterCodes=make([]uint16,0,len(ids))')
    s=one(s,'revisions := make(map[*subscription]uint64)','var meter *entity.M16PrepareObservation\n if gap!=nil {meter=&entity.M16PrepareObservation{Origin:gap.run.origin}}\n revisions := make(map[*subscription]uint64)')
    s=one(s,'var objBegin int64','var flags uint16; var copied,meterIndex int\n var objBegin int64')
    s=one(s,'objBegin = gap.run.now()','meter.Seen,meter.Result,meter.Holds=0,0,0; meterIndex=len(gap.w.Objects)\n objBegin = gap.run.now()')
    s=one(s,'deltaProfiles, snapshotProfiles := subj.profilesLocked(selectedSnapshots)','meter.Mark(1)\n deltaProfiles, snapshotProfiles := subj.profilesLocked(selectedSnapshots)')
    s=one(s,'if wantsCapture {\n\t\t\t//','meter.Mark(2)\n if wantsCapture {\n\t\t\t//')
    s=one(s,'subj.mu.Unlock()\n\t\t\tvar item','if meter!=nil {copied=len(revisions); meter.Mark(3)}\n subj.mu.Unlock()\n\t\t\tvar item')
    a='''if waiting {
				item, err = state.PrepareSnapshotViews(snapshotProfiles)
			} else {
				item, err = state.PrepareViews(deltaProfiles, snapshotProfiles)
			}
			subj.mu.Lock()'''
    s=one(s,a,'''if meter==nil {'''+a[:a.index('\n\t\t\tsubj.mu.Lock()')]+'''} else {
         meter.Result=10 // actual API entry; fallback for nondecision exits
         if waiting { flags|=1<<4; meter.Mark(4); item,err=state.M16PrepareSnapshotViews(meter,snapshotProfiles) } else {
             meter.Mark(4); item,err=state.M16PrepareViews(meter,deltaProfiles,snapshotProfiles)
         }
         meter.Mark(14)
         if err!=nil && (meter.Result==7 || meter.Result==8) {meter.Result=10}
     }
     subj.mu.Lock(); meter.Mark(15)''')
    for reason,k in [('commit_pending',1),('prepare_failed',2),('durability_wait',3)]:
        prefix='retry = append(retry, deferredSubject{id: id, reason: "'+reason+'"'
        line=[l for l in s.splitlines() if prefix in l]; assert len(line)==1
        s=one(s,line[0],line[0].replace('{id: id','{meterIndex:meterIndex,id: id')+'\n if meter!=nil {flags|='+str(k)+'<<5}')
    s=one(s,'objEnd := gap.run.now()','objEnd := gap.run.now()\n gap.meterVisit(meter,objBegin,objEnd,flags,copied)')
    s=one(s,'retryCaptured := func(cause error) {','retryCaptured := func(cause error) {\n if gap!=nil {gap.w.MeterRetryAll=true}')
    return one(s,'m.settleDeferrals(ids, retry)','m.m16SettleDeferrals(ids, retry, gap)')

def drain(s):
    s=one(s,'type deferredSubject struct {','type deferredSubject struct {\n meterIndex int')
    sig='func (m *Manager) settleDeferrals(processed []int64, retry []deferredSubject) {'
    s=one(s,sig,sig+'\n m.m16SettleDeferrals(processed,retry,nil)\n}\n'+sig.replace('settleDeferrals(','m16SettleDeferrals(').replace('[]deferredSubject)','[]deferredSubject,gap *m16GapRound)'))
    return one(s,'m.markPendingLocked(item.id)','''inserted:=m.markPendingLocked(item.id)
        if gap!=nil { if inserted {gap.w.MeterCodes[item.meterIndex]|=1<<7} else {gap.w.MeterCodes[item.meterIndex]|=2<<7} }''')

def transform(src):
    out=dict(src)
    if DR not in out:
        # Minimal three-file callers: read exactly the pinned, unoverlaid fourth source.
        p=Path(os.environ['MESHY_PROJECT'])/'.claude/worktrees/main-review-fixes'/DR
        data=p.read_bytes(); assert hashlib.sha256(data).hexdigest()=='277cc050048916be5de9a8acd5f20200a19fb25ca30cac8f649d09476f10f4df'
        out[DR]=data.decode()
    for f,fn in [(SUB,subject),(FL,flush),(GAP,gap),(DR,drain)]: out[f]=fn(out[f])
    for pkg,file in [(E,'entity_contract.go.in'),(S,'flush_contract.go.in')]:
        key=pkg+'m16_prepare_meter_test.go'
        if key in out: raise ValueError('preexisting test '+key)
        out[key]=(HERE/file).read_text()
    return out
