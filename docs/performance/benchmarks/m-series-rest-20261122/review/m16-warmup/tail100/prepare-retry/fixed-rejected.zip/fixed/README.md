# M16 prepare retry：无探针固定输入（冻结版）

这里是测试 overlay，不是 B 方案。只支持 `fix/main-review-fixes` 的 `24b704bf1627d4db3f64c4f87880bfce808af326`，加 `m16-rev-slot/prod-a` 的四个已钉 SHA 的产品文件。`overlay.json` 可直接给 Go；唯一新增的逻辑 key 是 `framework/sync/entitysync/m16_retry_fixed_test.go`。它不依赖任何旧的 `_test.go` helper、generated fixture、M16_* 环境变量、调试字段、额外标签、observer overlay 或服务。用生产 API 做所有输入，包内只在计时外读 `pendingMu/pending/deferrals` 来证明重排及原因/持续时间，并不写它们。该构建不更换生产计数逻辑。

## 冻结的输⼊与边界

四个固定场，没有参数扫描或 profile 百分位拟合。每个都是 **64 个注册的真实状态**、一个标准 profile、固定同尺寸不可变 payload（字节含对象身份），手动串行 Flush。`sparse` 每连续 8 个对象中六个零订阅、一个 1 个订阅、一个 4 个订阅，总计 40 条真实边，4 个会话。`dense` 每对象 128 个真实已 Open 的会话，总计 8192 条边。基线 MarkDirty、订阅与 Flush 均走产品 API，先给所有订阅建立 Full v1。没有模拟的引用表、预算、耐久延迟、会话 Hold 或重试注入。观测是对象访问的订阅数，不是交付给客户端的数目；这里只复现**hold+重试的输入**，不是 1000 客户端、政策时长或 c4 的缩小复刻。

- `*_held` 对全部对象各调用一次真实 `HoldSyncPublication()` / `MarkDirty(1)`；预热两次 Flush 后，重放 32 次相同自然重排，不在轮间标脏或补 pending。计时结束才全部 release；接收方各收一个基线连续的 delta，所有对象干净，源版本包括零订阅对象一并推进。这里“全量恢复”指**所有对象与所有仍订阅的会话完成恢复**，不要求把已有基线上的 delta 错发为 Full。
- `*_success` 使用完全相同的基线和订阅布局，所有对象无 hold；每轮计时前 MarkDirty，始终是同样数量的成功准备和交付；固定 32 次，版本和 tick 都在同一个 varint 宽度内。无 redirty 的收尾为空。两种场都校验准确的 dirty/frames/updates、无空 Flush、无丢会话，无未预期 Create/Remove。独立同构 6 轮 replay 对**每个** `(轮,SID,对象)` 核对存在与否、operation、Full、版本、base、codec、profile 和 payload，并将包含零帧行的原始长度分隔记录做 SHA-256，不靠自比计数保证等价。
- `ns/op` 是完整公开 `Manager.Flush` 的外部基准时间（含真实 settleDeferrals）；`capture-ns/op` 是正式 `Counters().CaptureDuration` 的增量（到订阅捕获/离开处理末尾，不含 settleDeferrals）；`internal-flush-ns/op` 是产品 `Counters().FlushDuration` 的增量（不含外部调用边界与部分 defer），分母都为**同一批已执行的 Flush 数**，而非“每个 subject”或“每组轮”。`B/op`、`allocs/op` 为标准 testing 计时区分配指标。`heap-allocs/sample` 是额外的整组未取整分配数（每次 Flush 外围采集 Mallocs 差，只作为对照 guard，固定 N 才可比较），可检出整除时被掩盖的小额外分配。它包括计时器启动/停止边界，不是对象级归因。MemStats、准备/建立订阅/放行/清帧/断言在计时区外，benchmark 的 transport 仅赋值到预分配 SID 槽，不解码或复制帧。没有服务或后台自动 Flush。稳定输入不代表 Go map 遍历序、时间或分配数逐样本不变。

## 必须通过的语义合同

小型 `TestM16RetryFixedReleaseOrder`：4 个对象（含一名无订阅）+3 个会话，7 次手动 Flush。每轮从真实解码器校验每一项、源版本及脏状态；持有期间断言 `(queued, deferral.reason/detail/err/since)`，连续重试不重置首次时间，成功后对应项删除。输出完整 little-endian 边界的 raw hex，不忽略零帧行：

| 轮 | 预期线行为 |
|---:|---|
| 1 | SID 1、2 分别 Create 对象 1、2、3，v1；零订阅对象 4 也提交至 v1 |
| 2 | 全部 held，全体无发布，四条 commit_pending |
| 3 | 对象 3 仍 held；SID 2 必须收到此前已见对象 3 的单条 Remove；新订阅 SID 3 此时无 Create |
| 4 | 仍 held：无重复 Remove、无新帧；四个版本和首次延期时间保持 |
| 5 | 放行对象 1；在它的**真实 delta packer** 内用 channel/join 确定另一 goroutine 已释放对象 2，再继续同一 Flush；两者在该轮都应发布 v1→v2。对象 3 去掉一层 hold 后仍被另一层阻挡。对象 3、4 均留队 v1 |
| 6 | 最后一批 release，不补标脏；1 对对象 3 收 Delta v2/base1，3 收首次 Full Create v2/base2，2 不再收到它，零订阅 4 单独提交；无对象留队 |
| 7 | 再 Flush 一次，无新帧、无重复提交 |

A、B 各 `-race -count=3` 执行这个小合同；较大的 4 个 wire replay 走非 race、串行 `-count=3`；每次的原始小 transcript、各形状大 transcript 摘要都必须逐一相同，且各自独立符合预期语义。**反向对照**：runner 在新的结果目录从冻结测试派生临时 overlay，只取消第 5 轮对象 2 的那一次释放，不改 oracle 或产品；小合同必须在 `round=5 sid=1 subject=2 missing/extra entry` 失败。编译失败、race、其它断言或超时不能算“抓住 bug”。这是测试灵敏度检验，不假称杀死尚未存在的 B 产品突变。候选涉及 revision 身份 / lifetime 等行为时，仍应额外运行候选针对性的并发改订阅/换 lifetime 合同；这里不降低那些要求。

## 预先确定主形状与决策门

在看 **B 跑分前**，只依据主线程已完整交付对账的原始 A c4 meter，取正式窗内完整、非 force、成功的轮，要求每条记录同时满足实际 `policy_hold`、追加 `commit_pending`、真实抵达 settle（inserted 或 already_pending）。按该条记录自身的对象 begin→end 取墙钟，不把成本分摊给个体。`0..8` 对 sparse，`65+` 对 dense，`9..64` 单列。某个可代表桶须占这批对象墙钟严格过半，并有同一对象在前后相邻轮真实重试见证；否则**不选主形状、不晋级**。返回类型仅 `commit_gate` 不能授权 policy-hold 仿真。这个选择只代表候选场；并不证明该时间可省、settle 自身耗时、或 c4 归因。父线程独立的经济性/语义筛选若未过，仍停止。

唯一预设主指标为完整 Flush `ns/op`：避免把代价搬出 capture 即算赢。依序 **A1、B1、B2、A2**，每组每场 5 × `32x`，两组都反转比较（B1 对 A1、B2 对 A2）。主场两对各组中位数严格改善且两侧各合并 10 次的中位数改善 ≥5%；各场（含另一 held 场及两种无 hold 成功对照）合并的 capture、整个调用和内部 flush 指标均不得回退 >5%。所有场 `allocs/op` 和 `heap-allocs/sample` 的两对及合并中位数都不得增加；同时报告 B/op，不能把 bytes 当次数。不排除异常样本，不按排序或阈值改主形状，不换参数补跑。工具不会因通过而自动跑 c4。

## 父线程执行入口

`F=$MESHY_WORK/m16-prepare-retry/fixed; D=${F%/fixed}`。不在已有共享锁内部嵌套调用 runner；它自己以 `LOCK_EX|LOCK_NB` 获取同一 `$MESHY_WORK/m-series-fixes/measure.lock`，持续到整个任务/批次结束，定期检查其他大负载；拿不到、发现并发、输入改变或输出目录已存在即失败，不能换锁/并发重跑。父线程若已有外层锁，可直接用 `F/overlay.json` 在该锁保护下调用相同 Go 命令；不要再调用内部取锁 runner。仅执行 A 合同/negative：

```sh
python3 -B "$F/run_fixed.py" a "$D/fixed-contracts-a"
```

只在原始 A c4 的 stock+meter+交付对账完成后、**尚未测 B** 时，父线程先保存选择证据：

```sh
(set -C; python3 -B "$F/gate.py" select "$D/c4/trace.json.gz" > "$D/fixed-selection.json")
```

仅在父线程经济性/正确性筛选通过并选定**一个** B 时，给产品-only B overlay（允许从 A 起的增量 key；禁止夹带测试、观测或 generated 文件）。程序不会制作产品补丁：

```sh
python3 -B "$F/run_fixed.py" pair "$D/fixed-pair" "$PRODUCT_B_OVERLAY" "$D/fixed-selection.json" "$D/c4/trace.json.gz"
```

输出新私有目录，含 A/B 有效 overlay、版本/命令/退出码、每份合同、negative、二进制哈希、逐组原始输出、原始样本、中位数和逐项 gate；未实际执行的实验没有成绩。`pins.json` 钉住输入；禁止编辑本目录或覆盖已产生的结果。本包交付时未运行 Go、服务、正式负载或 A/B。脚本 `python3 -B` 避免生成本目录 `__pycache__`。
