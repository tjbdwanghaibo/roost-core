"""Pure text recipes. No import-time assembly, Go, subprocess, or file writes.
transform() is solely product B, for use AFTER the parent opens the fixed gate.
contract_sources() is test-only and works independently on product A.
"""
from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
E='framework/sync/entitysync/'
PINS={'flush.go':'ca8cefbe4a06f9396a7b6066d034bcef96f593c8577c3cbee8f92fe161c5df09','subject.go':'c74ea8c07efdf69510fa034404247283df9e827bcd7c37f62dd2fc9254b14849','manager.go':'c99dc044ca7e5aac49e22ab82e6ea3eec862df74a598d85fdc3d02a9cff38797'}
sha=lambda b: hashlib.sha256(b).hexdigest()
def one(s,a,b):
    if s.count(a)!=1: raise ValueError('missing/ambiguous anchor: '+repr(a))
    return s.replace(a,b)

HELPERS='''// captureRevisionRow preserves the observed pointer identity AND its value, not its SID.
// Accessed by exactly one flushGate owner. No references escape to a sender or settlement.
type captureRevisionRow struct {
	sub *subscription
	revision uint64
}

// High-water LENGTH for this Flush. The persisted slice always has zero length and
// zeroed entries between Flushes. Use an exact transient allocation for exceptional
// fanout (configuration or pin bypass); DefaultMaxSubscribersPerSubject is a retention
// bound only and does not affect admission, subscriptions, or delivered objects.
func (m *Manager) linearRevisionsLocked(subj *subject) []captureRevisionRow {
	n := len(subj.subscribers)
	var rows []captureRevisionRow
	if n > DefaultMaxSubscribersPerSubject {
		rows = make([]captureRevisionRow, n)
	} else {
		if n > cap(m.flushRevisionRows) {
			capacity := max(n, min(2*cap(m.flushRevisionRows), DefaultMaxSubscribersPerSubject))
			m.flushRevisionRows = make([]captureRevisionRow, n, capacity)
		} else if n > len(m.flushRevisionRows) {
			m.flushRevisionRows = m.flushRevisionRows[:n]
		}
		rows = m.flushRevisionRows[:n]
	}
	i := 0
	for _, sub := range subj.subscribers {
		rows[i] = captureRevisionRow{sub:sub, revision:sub.revision}
		i++
	}
	return rows
}

func indexLinearRevisions(revisions map[*subscription]uint64, rows []captureRevisionRow) {
	clear(revisions)
	for _, row := range rows {
		revisions[row.sub] = row.revision
	}
}

func (m *Manager) releaseLinearRevisions() {
	clear(m.flushRevisionRows)
	m.flushRevisionRows = m.flushRevisionRows[:0]
}

'''

def transform(sources):
    result=dict(sources)
    for n,h in PINS.items():
        if sha(result[E+n].encode())!=h: raise ValueError('not pinned unprobed A: '+n)
    result[E+'subject.go']=one(result[E+'subject.go'],'\tretiring bool\n','\tretiring bool\n\t// Previous actual Prepare took the real commit_pending branch; hint only. Protected by mu.\n\tlastPrepareCommitPending bool\n')
    result[E+'manager.go']=one(result[E+'manager.go'],'\tflushPool         []*flushSession\n','\tflushPool         []*flushSession\n\tflushRevisionRows []captureRevisionRow // flushGate exclusive; zeroed before release\n')
    result[E+'manager.go']=one(result[E+'manager.go'],'\tsubj.state = state\n','\tsubj.state = state\n\tsubj.lastPrepareCommitPending = false\n')
    s=result[E+'flush.go']; s=one(s,'func (m *Manager) flush(ctx',HELPERS+'func (m *Manager) flush(ctx')
    s=one(s,'revisions := make(map[*subscription]uint64)','var revisions map[*subscription]uint64\n\tdefer m.releaseLinearRevisions()')
    s=one(s,'\t\tif wantsCapture {\n\t\t\t//','\t\tif wantsCapture {\n\t\t\tlazy := subj.lastPrepareCommitPending\n\t\t\t//')
    s=one(s,'\t\t\tsubj.mu.Lock()\n\t\t\tswitch {','\t\t\tsubj.mu.Lock()\n\t\t\tsameState := subj.state == state\n\t\t\tif sameState {\n\t\t\t\tsubj.lastPrepareCommitPending = false\n\t\t\t}\n\t\t\tswitch {')
    a='''			clear(revisions)
			for _, sub := range subj.subscribers {
				revisions[sub] = sub.revision
			}'''
    s=one(s,a,''' 			var rows []captureRevisionRow
			if lazy {
				rows = m.linearRevisionsLocked(subj)
			} else {
				if revisions == nil {
					revisions = make(map[*subscription]uint64)
				} else {
					clear(revisions)
				}
				for _, sub := range subj.subscribers {
					revisions[sub] = sub.revision
				}
			}'''.lstrip(' '))
    s=one(s,'\t\t\tcase errors.Is(err, entity.ErrSyncCommitPending):\n','\t\t\tcase errors.Is(err, entity.ErrSyncCommitPending):\n\t\t\t\tif sameState {\n\t\t\t\t\tsubj.lastPrepareCommitPending = true\n\t\t\t\t}\n')
    anchor='\t\t\t\tsnapshots, deltas := captureUpdates(&captures, snapshotUpdates), captureUpdates(&captures, deltaUpdates)\n'
    s=one(s,anchor,anchor+'''\t\t\t\tif lazy {
					if revisions == nil {
						revisions = make(map[*subscription]uint64)
					}
					indexLinearRevisions(revisions, rows)
				}
'''); result[E+'flush.go']=s
    return result

def mutant(product, name):
    r=dict(product);s=r[E+'flush.go']
    if name=='reread':s=one(s,'revisions[row.sub] = row.revision','revisions[row.sub] = row.sub.revision')
    elif name=='hint-authorizes':s=one(s,'\t\t\tif waiting {\n\t\t\t\titem, err = state.PrepareSnapshotViews','\t\t\tif lazy {\n\t\t\t\terr = entity.ErrSyncCommitPending\n\t\t\t} else if waiting {\n\t\t\t\titem, err = state.PrepareSnapshotViews')
    elif name=='stale-map':s=one(s,'\tclear(revisions)\n\tfor _, row := range rows','\tfor _, row := range rows')
    elif name=='keep-references':s=one(s,'\tclear(m.flushRevisionRows)\n','')
    else:raise ValueError(name)
    r[E+'flush.go']=s;return r

def contract_sources(legacy,fixed,side):
    legacy,fixed=Path(legacy),Path(fixed);assert side in ('a','b')
    r={E+p.name:p.read_text() for p in sorted(legacy.glob('*_test.go'))}
    if len(r)!=11:raise ValueError('expected eleven prior wire/semantic contracts')
    r[E+'m16_retry_fixed_test.go']=(fixed/'retry_fixed_test.go').read_text()
    r[E+'m16_lazy_test.go']=(D/'contract.go.in').read_text()
    if side=='b':r[E+'m16_lazy_storage_test.go']=(D/'storage.go.in').read_text()
    return r
