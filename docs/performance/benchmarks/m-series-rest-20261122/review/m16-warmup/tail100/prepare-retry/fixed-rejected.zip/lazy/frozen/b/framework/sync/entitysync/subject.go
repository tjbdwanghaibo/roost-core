package entitysync

import (
	"cmp"
	"fmt"
	"slices"
	"sync"
	"time"

	"github.com/tjbdwanghaibo/roost-core/framework/entity"
)

// subscriptionKind is where one session stands with respect to one subject.
type subscriptionKind uint8

const (
	// kindSnapshot：等待全量快照。首次订阅尚无对象，换 profile 或撤回退订时
	// 则可能仍持有旧对象；是否欠 remove 必须查会话的已交付引用表。
	kindSnapshot subscriptionKind = iota + 1
	// kindLive: holds baseVersion; the next frame carries a delta from it.
	kindLive
	// kindLeaving: unsubscribed or the subject is retiring; the next frame
	// carries an ObjectRemove and the entry is dropped.
	kindLeaving
)

// subscription is one session's standing with one subject: the profile the
// session wants, the kind of frame it is owed, and the version it holds.
type subscription struct {
	// revision 标识订阅意图；inFlight 防止首次快照在途时丢掉待删除记录。
	revision uint64
	inFlight bool
	// overLimit：超额暂缓（over_limit.go）。只对 kindSnapshot 且会话未持有对象的订阅有意义：会话里这一类已满，
	// 这个新对象本轮没有创建，在会话出现空位之前不参与捕获、不进快照预算索引、不让 Drain 等待；
	// 空位出现时由 releaseOverLimit 清除并重新排进 pending。离开 kindSnapshot 时随之清除（changeSubscriptionKindLocked）。
	// 放在 inFlight 旁边占它的填充字节，不加大结构体。
	overLimit bool
	// codec 是会话持有的基线（最近一次交付并结算的全量）载荷的 codec。增量信封不带 codec，接收端按它解增量载荷，
	// 所以非空增量的 codec 与它不同时不能发增量，改发全量（codecMismatchLocked）。同样放在填充字节里。
	codec    uint16
	lifetime *sessionLifetime
	sources  map[*SubscriptionSource]entity.SyncProfile
	profile  entity.SyncProfile
	kind     subscriptionKind
	// snapshotClass 只决定冷对象创建的调度；有效 Profile 和线协议语义不变。
	snapshotClass snapshotClass
	baseVersion   uint64
	// sendWaiting 只在成功结算后清除，新脏数据不能刷新等待年龄。
	sendWaiting time.Time
	// overLimitNoticed 是最近一次为这个暂缓的订阅通知来源的时刻（overLimitClock，单调时钟纳秒；renotifyOverLimit 据此隔
	// overLimitRenotifyInterval 再通知）。用 int64 而不是 time.Time：每个订阅都带这个字段，省 16 字节。
	overLimitNoticed int64
	// pinnedBy 是以 SubscribePinned 订阅它的来源（通常只有自身视图）；非空即“钉住”：超额时永不暂缓，
	// 必要时挤掉同类里优先级最低的未钉住对象。nil 表示没有来源钉住，常见路径不分配。
	pinnedBy map[*SubscriptionSource]struct{}
}

// pinned 报告订阅是否被某个来源钉住；调用方持有 subject.mu。
func (s *subscription) pinned() bool { return len(s.pinnedBy) > 0 }

// waitsForRoom 报告订阅是否处于超额暂缓；调用方持有 subject.mu。
func (s *subscription) waitsForRoom() bool { return s.kind == kindSnapshot && s.overLimit }

// subject is an entity's sync state plus its subscribers. The subscribers
// live HERE, not in an index somewhere else: the subject is the truth about
// who receives it.
type subject struct {
	mu sync.Mutex
	id int64
	// state 是实体的内容状态；实体卸载后重新加载时由 Rebind 在 mu 下替换，读者在 mu 下取用。
	state         *entity.SubjectSyncState
	cadence       *subjectCadence // 仅显式周期类型分配；Rebind 时替换
	subscribers   map[SessionID]*subscription
	lastSlotAdded SubscriptionStamp // 最近分配会话槽的戳；来源合并不变，已释放槽由空位数反映。
	// class 是 subject 的类别（ManagerConfig.Namespaces）：决定会话持有上限按哪一类计、快照走哪一路预算。
	// 登记时按命名空间确定，之后不变（Rebind 换状态也不变），无锁读。
	class uint8
	// retiring: Unregister was called; every subscriber is leaving and the
	// subject is forgotten once the last remove has gone out.
	retiring bool
	// Previous actual Prepare took the real commit_pending branch; hint only. Protected by mu.
	lastPrepareCommitPending bool
	// successor 是 RegisterAfterRetirement 排在退役完成之后登记的状态，至多一个；
	// forgotten 表示 forget 已经取走 successor，之后不能再排队（调用方改走 Register）。
	successor *queuedRegistration
	forgotten bool
	// unloadRetracted：退役来自 RetractUnloadedSubject（实体被仅内存卸载后重载不了），不是业务
	// Unregister。退役完成前该实体又被加载出来时，Rebind / Register 把新状态排在退役完成之后登记
	// （RegisterAfterRetirement 的同一机制），不返回 ErrSubjectRetiring。业务再 Unregister 时清除。
	unloadRetracted bool
	// 缓存发布后不可修改；CaptureSync 解开 subject 锁后仍会使用这两组需求。
	// 增删订阅以及有效 profile/kind 改变必须使 profilesValid 失效。
	profilesValid                   bool
	deltaProfiles, snapshotProfiles []entity.SyncProfile
}

// currentState 读取当前内容状态；Rebind 会在 subject.mu 下替换它。
func (s *subject) currentState() *entity.SubjectSyncState {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.state
}

func newSubject(state *entity.SubjectSyncState) *subject {
	return &subject{id: state.SubjectID(), state: state, subscribers: make(map[SessionID]*subscription)}
}

// profilesLocked 一次遍历收集两种内容需求，不在订阅数量上反复建立 profile map。
// 内容层统一规范化、去重和排序；held 会话仍保留原有捕获语义。
func (s *subject) profilesLocked(selected map[*subscription]bool) (delta, snapshot []entity.SyncProfile) {
	if !s.profilesValid {
		s.deltaProfiles, s.snapshotProfiles = s.collectProfilesLocked(nil)
		s.profilesValid = true
	}
	if selected == nil {
		return s.deltaProfiles, s.snapshotProfiles
	}
	// 空选择不必遍历订阅；非空集合只过滤预算相关的快照需求。
	if len(selected) == 0 {
		return s.deltaProfiles, nil
	}
	_, snapshot = s.collectProfilesLocked(selected)
	return s.deltaProfiles, snapshot
}

func (s *subject) collectProfilesLocked(selected map[*subscription]bool) (delta, snapshot []entity.SyncProfile) {
	for _, sub := range s.subscribers {
		switch sub.kind {
		case kindLive:
			if selected == nil && !slices.Contains(delta, sub.profile) {
				delta = append(delta, sub.profile)
			}
		case kindSnapshot:
			if sub.overLimit || selected != nil && !selected[sub] {
				continue // 超额暂缓的订阅等会话有空位再捕获
			}
			if !slices.Contains(snapshot, sub.profile) {
				snapshot = append(snapshot, sub.profile)
			}
		}
	}
	return delta, snapshot
}

// sessionsLocked lists the subscribed sessions in ascending order.
func (s *subject) sessionsLocked() []SessionID {
	ids := make([]SessionID, 0, len(s.subscribers))
	for id := range s.subscribers {
		ids = append(ids, id)
	}
	slices.Sort(ids)
	return ids
}

// bestProfile 的排序只决定已授权视图的选择，不推断字段之间的包含关系。
func (m *Manager) bestProfile(profiles map[*SubscriptionSource]entity.SyncProfile) entity.SyncProfile {
	var best entity.SyncProfile
	first := true
	for _, profile := range profiles {
		if first || m.CompareProfiles(profile, best) < 0 {
			best = profile
			first = false
		}
	}
	return best
}

// ValidateViewPriority 检查 packer 视图与 Manager 的实际选择顺序是否使用同一配置。
func (m *Manager) ValidateViewPriority(view entity.SyncView) error {
	if priority := m.profilePriority(view.Profile); priority != view.Priority {
		return fmt.Errorf("entitysync: profile %+v priority is %d, view declares %d", view.Profile, priority, view.Priority)
	}
	return nil
}

func compareProfiles(a, b entity.SyncProfile) int {
	if order := cmp.Compare(a.LOD, b.LOD); order != 0 {
		return order
	}
	if order := cmp.Compare(a.Key, b.Key); order != 0 {
		return order
	}
	return cmp.Compare(a.SchemaVersion, b.SchemaVersion)
}

// CompareProfiles 将业务优先级与稳定平局规则集中在一处，Interest 与多政策来源共用。
func (m *Manager) CompareProfiles(a, b entity.SyncProfile) int {
	a, b = a.Normalize(), b.Normalize()
	if order := cmp.Compare(m.profilePriority(a), m.profilePriority(b)); order != 0 {
		return order
	}
	return compareProfiles(a, b)
}

// profilePriority 是一个视图的业务优先级：配置了的按配置，未配置的按 LOD。层级并集（entity.UnionSyncProfiles）
// 取各层级里最优（最小）的那个，与 entity.SyncViewSet.Lookup 给并集的 Priority 是同一条规则，ValidateViewPriority 才对得上。
func (m *Manager) profilePriority(profile entity.SyncProfile) int {
	layers := profile.Layers()
	best := 0
	for index, layer := range layers {
		rank, ok := m.config.ProfilePriorities[layer]
		if !ok {
			rank = int(layer.LOD)
		}
		if index == 0 || rank < best {
			best = rank
		}
	}
	return best
}
