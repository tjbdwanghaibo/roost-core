"""Only invoke once the precommitted fixed gate has passed. One unprobed original c4, not a pair."""
from base import *
from validate100 import validate,private_localhost
bi=Path(sys.argv[1]).resolve();expected=sys.argv[2];assert sha(bi.read_bytes())==expected;out=D/'product-c4';series=out/'m-series-fixes';tag='prepare-retry-unprobed';sub=series/tag;driver=S/'run-m16.py';en={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL','LC_CTYPE','TZ')};en.update(MESHY_WORK=str(out),ROOST_NEST_GAME_WARMUP='30s',ROOST_NEST_GAME_SELF_SYNC='0',ROOST_NEST_GAME_EMBEDDED='0',ROOST_NEST_GAME_HEARTBEAT_DRIVER='ticker',ROOST_NEST_GAME_MESSAGE_TARGETS='1000',PYTHONDONTWRITEBYTECODE='1');assert not any(k.startswith('M16_') for k in en)
with (S/'measure.lock').open('r+b') as f:
 fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);snaps=[isolation('before')];clear(snaps[-1]);out.mkdir();series.mkdir();start=time.monotonic_ns()
 with (out/'runner.log').open('x') as log:
  child=sp.Popen([sys.executable,'-B',driver,tag,'1000','4',bi],cwd=R,env=en,stdout=log,stderr=sp.STDOUT,start_new_session=True,pass_fds=(f.fileno(),));
  try:
   while True:
    try:rc=child.wait(timeout=10);break
    except sp.TimeoutExpired:snaps.append(isolation('during',child.pid));clear(snaps[-1])
  except BaseException:stop_group(child);raise
 snaps.append(isolation('after'));clear(snaps[-1]);(out/'exit.json').write_text(json.dumps(dict(original_exit=rc,binary=expected,runner=sha(driver.read_bytes()),elapsed_ns=time.monotonic_ns()-start,isolation=snaps),indent=2)+'\n')
r=json.loads((sub/'sample.json').read_bytes());text=(sub/'run.log').read_text();v=validate(r,text,rc);v['private_ports']=private_localhost(text,[(sub/f'nats-{i}.log').read_text() for i in range(3)]);(out/'checked.json').write_text(json.dumps(v,indent=2)+'\n');print('original',v['original_verdict'],rc,'All',r['SyncReport']['CommittedDeliveries']['All'],'gates',v['gates'],'all_end_values',v['all_player_final_values'])
