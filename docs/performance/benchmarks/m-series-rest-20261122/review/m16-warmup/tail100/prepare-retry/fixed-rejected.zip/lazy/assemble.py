"""Parent-authorized serial source assembly. No Go commands. Never overwrites artifacts."""
from recipe import D,E,PINS,sha,transform,contract_sources,mutant
from pathlib import Path
import os,json,sys,difflib,subprocess
W=Path(os.environ['MESHY_WORK']).resolve();R=Path(os.environ['MESHY_PROJECT']).resolve()/'.claude/worktrees/main-review-fixes';A=W/'m16-rev-slot/prod-a';L=W/'m16-tail-sweep/fixed/inputs';F=D.parent/'fixed';O=D/'frozen';read=lambda p:json.loads(Path(p).read_bytes())
h=lambda p:sha(Path(p).read_bytes())
def put(p,b):
    p.parent.mkdir(parents=True,exist_ok=True);p.open('xb').write(b.encode() if isinstance(b,str) else b);p.chmod(0o444)
def dump(p,obj):put(p,json.dumps(obj,sort_keys=True,indent=2)+'\n')
def verify():
    assert sys.dont_write_bytecode and __debug__ and D==W/'m16-prepare-retry/lazy'; assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='24b704bf1627d4db3f64c4f87880bfce808af326';assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all','--','framework','codegen','go.mod','go.sum'],cwd=R)
    s=read(D.parent/'c4/screen.json');assert s['worth_fixed'] is True and all(s['conditions'].values()) and s['groups']['formal']['hint_pending_again']==657245 and s['groups']['formal']['pending_calls']==659932
    assert read(D.parent/'c4/stock.json')['trace']=='1c9e9e84cbbbd53735cf620b0480788be88439b2f518840c34bdb6dcfeb18152'
    j=read(L/'historical-hashes.json');mp=read(A/'overlay.json')['Replace'];assert mp=={str(R/n):str(A/n) for n in j['baseline']} and {n:h(A/n) for n in j['baseline']}==j['baseline'];return mp

def main():
    mp=verify();side=sys.argv[1];src={E+n:Path(mp.get(str(R/E/n),R/E/n)).read_text() for n in PINS}
    if side=='product':
        b=transform(src);bp={};diff=[]
        for n,v in sorted(b.items()):
            key=str(R/n);p=O/'b'/n;put(p,v);bp[key]=str(p);diff.extend(difflib.unified_diff(src[n].splitlines(True),v.splitlines(True),'a/'+n,'b/'+n))
        put(O/'product.patch',''.join(diff));dump(O/'product-b.json',{'Replace':mp|bp});return
    assert side=='tests';prod=read(O/'product-b.json')['Replace'];b={n:Path(prod[str(R/n)]).read_text() for n in src};assert transform(src)==b
    assert h(L/'historical-hashes.json')=='d07625598a900b990b65014d2c89315ebecd45084fb3e4b77668d88db3789827'; assert {p.name:h(p) for p in (L/'contracts').glob('*_test.go')}=={Path(n).name:v for n,v in read(L/'historical-hashes.json')['staged'].items() if n.startswith('staged/contracts/') and not n.endswith('/m16_sid_local_test.go')}
    maps={}
    for tag,pr in [('a',mp),('b',prod)]:
        tests=contract_sources(L/'contracts',F,tag);ts={}
        for n,v in tests.items():
            key=str(R/n);assert not Path(key).exists();name=Path(n).name
            if (L/'contracts'/name).exists():p=L/'contracts'/name
            elif name=='m16_retry_fixed_test.go':p=F/'retry_fixed_test.go'
            else:
                p=O/'contracts'/name
                if not p.exists():put(p,v)
            assert p.read_text()==v;ts[key]=str(p)
        maps[tag]=pr|ts;dump(O/('tests-'+tag+'.json'),{'Replace':maps[tag]})
    for name in ('reread','hint-authorizes','stale-map','keep-references'):
        n=E+'flush.go';p=O/'negative'/name/n;put(p,mutant(b,name)[n]);dump(O/('negative-'+name+'.json'),{'Replace':maps['b']|{str(R/n):str(p)}})
    files={p.relative_to(O).as_posix():h(p) for p in sorted(O.rglob('*')) if p.is_file()};dependencies={v:h(v) for mp_ in maps.values() for v in mp_.values() if not Path(v).is_relative_to(O)};dump(O/'pins.json',{'frozen':files,'dependencies':dependencies,'scripts':{n:h(D/n) for n in ['recipe.py','assemble.py','contract.go.in','storage.go.in','run.py']},'stock_trace_sha256':read(D.parent/'c4/stock.json')['trace']})
if __name__=='__main__':main()
